<?php
    $corteActual = \App\Support\CorteActivo::actual();
    $cortesDisponibles = \App\Models\AnioLectivo::with('estadoAnio')->orderByDesc('anio')->get();
?>

<?php if($cortesDisponibles->isNotEmpty()): ?>
    <form method="POST" action="<?php echo e(route('corte.seleccionar')); ?>" class="flex items-center gap-2 rounded-full bg-[#0B3D91] pl-3 pr-1 py-1 shadow-sm">
        <?php echo csrf_field(); ?>
        <label for="select-corte-activo" class="text-[10px] font-bold text-[#FFD54F] uppercase tracking-[.14em]">Año lectivo</label>
        <select id="select-corte-activo" name="id_anio_lectivo" onchange="this.form.submit()"
                class="rounded-full border-0 bg-white pl-3 pr-7 py-1 text-xs font-bold text-[#0B3D91] cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#4FC3F7]">
            <?php $__currentLoopData = $cortesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $corte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($corte->id_anio_lectivo); ?>" <?php if($corteActual?->id_anio_lectivo === $corte->id_anio_lectivo): echo 'selected'; endif; ?>>
                    <?php echo e($corte->anio); ?><?php echo e($corte->estadoAnio?->nombre_estado !== 'Activo' ? ' (Cerrado)' : ''); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>
<?php endif; ?>
<?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/partials/corte-selector.blade.php ENDPATH**/ ?>