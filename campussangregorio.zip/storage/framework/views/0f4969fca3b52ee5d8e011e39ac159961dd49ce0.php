
<section class="landing-contadores landing-franja-viva landing-seccion" style="padding:64px 0;" aria-label="Datos de la institución">
    <div class="landing-seccion__blobs" aria-hidden="true">
        <span class="landing-burbuja" style="width:220px;height:220px;background:var(--landing-celeste);opacity:.18;top:-70px;left:10%;animation-delay:-3s;"></span>
        <span class="landing-burbuja" style="width:180px;height:180px;background:var(--landing-amarillo);opacity:.14;bottom:-60px;right:8%;animation-delay:-8s;"></span>
    </div>
    <div class="landing-contenedor landing-grid landing-grid--4">
        <?php $__currentLoopData = $contadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="landing-contador landing-reveal" style="--landing-retraso:<?php echo e($i * 90); ?>ms">
                <p class="landing-contador__num">
                    <span data-landing-contar="<?php echo e($c['valor']); ?>" data-landing-sufijo="<?php echo e($c['sufijo']); ?>">0</span>
                </p>
                <p class="landing-contador__etq"><?php echo e($c['etiqueta']); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/landing/partials/contadores.blade.php ENDPATH**/ ?>