
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['titulo' => null, 'subtitulo' => null, 'icono' => null, 'tono' => 'azul', 'cuerpo' => true]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['titulo' => null, 'subtitulo' => null, 'icono' => null, 'tono' => 'azul', 'cuerpo' => true]); ?>
<?php foreach (array_filter((['titulo' => null, 'subtitulo' => null, 'icono' => null, 'tono' => 'azul', 'cuerpo' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<section <?php echo e($attributes->merge(['class' => 'sg-card sg-revelar'])); ?>>
    <?php if($titulo): ?>
        <header class="sg-card__head">
            <div class="sg-card__titulo">
                <?php if($icono): ?>
                    <span class="sg-chip sg-chip--chico sg-chip--<?php echo e($tono); ?>"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => $icono]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icono)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <?php endif; ?>
                <div class="min-w-0">
                    <h3><?php echo e($titulo); ?></h3>
                    <?php if($subtitulo): ?>
                        <p><?php echo e($subtitulo); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(isset($acciones)): ?>
                <div class="flex items-center gap-2 flex-wrap"><?php echo e($acciones); ?></div>
            <?php endif; ?>
        </header>
    <?php endif; ?>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sg-card__body' => $cuerpo]) ?>"><?php echo e($slot); ?></div>
    <?php if(isset($pie)): ?>
        <footer class="sg-card__foot"><?php echo e($pie); ?></footer>
    <?php endif; ?>
</section>
<?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/components/sg/tarjeta.blade.php ENDPATH**/ ?>