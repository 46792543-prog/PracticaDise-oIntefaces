

<?php $__env->startSection('titulo', 'Ficha del alumno'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php
        $inscripcion = $alumno->inscripcionesCarrera->first();
        $estadoInscNombre = $inscripcion?->estadoInscripcion?->nombre_estado;
        $cuotasPagadas = $alumno->cuotas->where('pagado', true)->count();
        $cuotasPendientes = $alumno->cuotas->where('pagado', false)->count();
        $cuotasVencidas = $alumno->cuotas->filter(fn ($c) => $c->vencida)->count();
    ?>

    <a href="<?php echo e(route('admin.alumnos.index')); ?>" class="sg-link mb-4 sg-revelar"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'arrow-left','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'arrow-left','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Volver al listado</a>

    
    <section class="sg-card sg-revelar overflow-hidden mb-6">
        <div class="h-24 bg-gradient-to-r from-[#082A66] via-[#0B3D91] to-[#4FC3F7] relative overflow-hidden">
            <span class="absolute -right-10 -top-16 h-48 w-48 rounded-full border-[14px] border-[#FFC107]/25"></span>
            <span class="absolute inset-0 opacity-10" style="background-image: radial-gradient(circle at 1px 1px, white 1px, transparent 0); background-size: 18px 18px;"></span>
        </div>
        <div class="relative px-6 pb-6 flex items-end justify-between flex-wrap gap-5">
            <div class="flex items-end gap-4 min-w-0">
                <span class="sg-avatar sg-avatar--grande sg-avatar--marca h-20 w-20 shrink-0 -mt-10 text-2xl ring-4 ring-white shadow-lg">
                    <?php echo e(mb_substr($alumno->nombre, 0, 1)); ?><?php echo e(mb_substr($alumno->apellido, 0, 1)); ?>

                </span>
                <div class="pt-3 min-w-0">
                    <div class="flex items-center gap-2 flex-wrap">
                        <h1 class="font-display font-extrabold text-xl text-slate-900"><?php echo e($alumno->apellido); ?>, <?php echo e($alumno->nombre); ?></h1>
                        <?php if($estadoInscNombre === 'Activo'): ?>
                            <span class="sg-badge sg-badge--verde">Activo</span>
                        <?php elseif($estadoInscNombre === 'Baja'): ?>
                            <span class="sg-badge sg-badge--rojo">Baja</span>
                        <?php endif; ?>
                    </div>
                    <p class="text-sm text-slate-500 mt-0.5">DNI <?php echo e($alumno->dni); ?> · <?php echo e($inscripcion?->carrera?->nombre_carrera ?? 'Sin carrera asignada'); ?></p>
                </div>
            </div>
            <div class="flex gap-2 flex-wrap">
                <a href="<?php echo e(route('admin.documentacion.show', $alumno)); ?>" class="sg-btn sg-btn--borde sg-btn--chico"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'folder']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'folder']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Documentación</a>
                <?php if($inscripcion && $inscripcion->estadoInscripcion->nombre_estado === 'Activo'): ?>
                    <a href="<?php echo e(route('admin.alumnos.materias', $alumno)); ?>" class="sg-btn sg-btn--azul sg-btn--chico"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'cap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'cap']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Inscribir a materias</a>
                <?php endif; ?>
                <?php if($progresoPromocion): ?>
                    <form method="POST" action="<?php echo e(route('admin.alumnos.promover', $alumno)); ?>"
                          onsubmit="return confirm('¿Promover a <?php echo e($alumno->nombre); ?> <?php echo e($alumno->apellido); ?> a <?php echo e($progresoPromocion['proximoAnio']->nombre_anio); ?>?');">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <button type="submit" <?php if(! $progresoPromocion['puede']): echo 'disabled'; endif; ?>
                                title="<?php echo e($progresoPromocion['aprobadas']); ?> de <?php echo e($progresoPromocion['total']); ?> materias de su año aprobadas<?php echo e($progresoPromocion['puede'] ? '' : ' — hace falta la mayoría para promover'); ?>"
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sg-btn sg-btn--chico', 'sg-btn--verde' => $progresoPromocion['puede'], 'sg-btn--borde opacity-50 cursor-not-allowed' => ! $progresoPromocion['puede']]) ?>">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'trending-up']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'trending-up']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            Promover a <?php echo e($progresoPromocion['proximoAnio']->nombre_anio); ?>

                            <span class="text-xs opacity-80">(<?php echo e($progresoPromocion['aprobadas']); ?>/<?php echo e($progresoPromocion['total']); ?>)</span>
                        </button>
                    </form>
                <?php endif; ?>
                <?php if($inscripcion && $inscripcion->estadoInscripcion->nombre_estado === 'Activo'): ?>
                    <form method="POST" action="<?php echo e(route('admin.alumnos.baja', $alumno)); ?>" onsubmit="return confirm('¿Confirmás dar de baja a este alumno?');">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <button type="submit" class="sg-btn sg-btn--peligro sg-btn--chico"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'user-minus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'user-minus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Dar de baja</button>
                    </form>
                <?php elseif($inscripcion && $inscripcion->estadoInscripcion->nombre_estado === 'Baja'): ?>
                    <form method="POST" action="<?php echo e(route('admin.alumnos.alta', $alumno)); ?>" onsubmit="return confirm('¿Confirmás dar de alta nuevamente a este alumno?');">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <button type="submit" class="sg-btn sg-btn--verde sg-btn--chico"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'user-plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'user-plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Dar de alta</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <div class="grid lg:grid-cols-3 gap-6 mb-6" data-sg-escalonar>
        <div class="sg-card p-5">
            <div class="flex items-center gap-3 mb-4">
                <span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'user']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'user']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <h3 class="font-display font-bold text-slate-800 text-sm">Datos personales</h3>
            </div>
            <dl class="text-sm space-y-3">
                <div class="flex justify-between gap-3"><dt class="text-slate-400 flex items-center gap-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'mail','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'mail','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Email</dt><dd class="text-slate-700 font-medium truncate"><?php echo e($alumno->usuario->email ?? '—'); ?></dd></div>
                <div class="flex justify-between gap-3"><dt class="text-slate-400 flex items-center gap-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'phone','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'phone','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Teléfono</dt><dd class="text-slate-700 font-medium"><?php echo e($alumno->telefono ?? '—'); ?></dd></div>
                <div class="flex justify-between gap-3"><dt class="text-slate-400 flex items-center gap-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'calendar','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'calendar','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Nacimiento</dt><dd class="text-slate-700 font-medium"><?php echo e(\App\Support\FechaEsp::corta($alumno->fecha_nacimiento)); ?></dd></div>
                <div class="flex justify-between gap-3"><dt class="text-slate-400 flex items-center gap-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'map','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'map','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Localidad</dt><dd class="text-slate-700 font-medium"><?php echo e($alumno->localidad ?? '—'); ?></dd></div>
            </dl>
        </div>
        <div class="sg-card p-5">
            <div class="flex items-center gap-3 mb-4">
                <span class="sg-chip sg-chip--chico sg-chip--amarillo"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'cap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'cap']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <h3 class="font-display font-bold text-slate-800 text-sm">Situación académica</h3>
            </div>
            <dl class="text-sm space-y-2.5">
                <div class="flex justify-between"><dt class="text-slate-400">Fecha de ingreso</dt><dd class="text-slate-700 font-medium"><?php echo e($inscripcion?->fecha_inscripcion ? \App\Support\FechaEsp::corta($inscripcion->fecha_inscripcion) : '—'); ?></dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Año lectivo</dt><dd class="text-slate-700 font-medium"><?php echo e($inscripcion?->anioLectivo?->anio ?? '—'); ?></dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Año que cursa</dt><dd class="text-slate-700 font-medium"><?php echo e($inscripcion?->anioCursada?->nombre_anio ?? '—'); ?></dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Turno</dt><dd class="text-slate-700 font-medium"><?php echo e($inscripcion?->turnoCursada?->nombre_turno ?? '—'); ?></dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Condición</dt><dd class="text-slate-700 font-medium"><?php echo e($inscripcion?->condicion?->nombre_condicion ?? '—'); ?></dd></div>
                <div class="flex justify-between items-center"><dt class="text-slate-400">Estado</dt><dd>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sg-badge', 'sg-badge--verde' => $estadoInscNombre === 'Activo', 'sg-badge--rojo' => $estadoInscNombre === 'Baja']) ?>">
                        <?php echo e($estadoInscNombre ?? '—'); ?>

                    </span>
                </dd></div>
            </dl>
        </div>
        <div class="sg-card p-5">
            <div class="flex items-center gap-3 mb-4">
                <span class="sg-chip sg-chip--chico sg-chip--verde"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'banknotes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'banknotes']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <h3 class="font-display font-bold text-slate-800 text-sm">Cuotas</h3>
            </div>
            <div class="grid grid-cols-3 gap-2 text-center">
                <div class="rounded-xl bg-emerald-50 py-3">
                    <p class="font-display text-2xl font-extrabold text-emerald-600" data-sg-contar><?php echo e($cuotasPagadas); ?></p>
                    <p class="text-[11px] font-semibold text-emerald-700/80">Pagadas</p>
                </div>
                <div class="rounded-xl bg-amber-50 py-3">
                    <p class="font-display text-2xl font-extrabold text-amber-600" data-sg-contar><?php echo e($cuotasPendientes); ?></p>
                    <p class="text-[11px] font-semibold text-amber-700/80">Pendientes</p>
                </div>
                <div class="rounded-xl bg-rose-50 py-3">
                    <p class="font-display text-2xl font-extrabold text-rose-600" data-sg-contar><?php echo e($cuotasVencidas); ?></p>
                    <p class="text-[11px] font-semibold text-rose-700/80">Vencidas</p>
                </div>
            </div>
            <?php if($alumno->cuotas->count() > 0): ?>
                <div class="sg-progreso mt-4"><span style="width: <?php echo e(round($cuotasPagadas / max($alumno->cuotas->count(), 1) * 100)); ?>%"></span></div>
                <p class="text-xs text-slate-400 mt-2"><?php echo e($cuotasPagadas); ?> de <?php echo e($alumno->cuotas->count()); ?> cuotas abonadas</p>
            <?php endif; ?>
        </div>
    </div>

    <?php
        $cuotasOrdenadas = $alumno->cuotas->sortBy([['id_anio_lectivo', 'asc'], ['id_mes', 'asc']]);
        $cuotasAdeudadasCount = $cuotasOrdenadas->where('pagado', false)->count();
        $totalEstimadoAdeudado = $montoActualCuota ? $cuotasAdeudadasCount * (float) $montoActualCuota : null;
    ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.tarjeta','data' => ['titulo' => 'Historial de Cuotas','subtitulo' => 'Todas las cuotas generadas para este alumno, pagadas y pendientes','icono' => 'banknotes','tono' => 'verde','class' => 'mb-6','cuerpo' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.tarjeta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Historial de Cuotas','subtitulo' => 'Todas las cuotas generadas para este alumno, pagadas y pendientes','icono' => 'banknotes','tono' => 'verde','class' => 'mb-6','cuerpo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
        <?php if($cuotasAdeudadasCount > 0 && $montoActualCuota): ?>
            <div class="mx-5 mt-4 flex items-center justify-between gap-3 rounded-2xl bg-gradient-to-r from-[#0B3D91] to-[#1565C0] text-white px-5 py-3">
                <span class="text-sm font-semibold text-blue-100">Adeuda <?php echo e($cuotasAdeudadasCount); ?> cuota<?php echo e($cuotasAdeudadasCount === 1 ? '' : 's'); ?> × $ <?php echo e(number_format($montoActualCuota, 0, ',', '.')); ?> (monto actual)</span>
                <span class="font-display font-extrabold text-xl text-[#FFD54F]">$ <?php echo e(number_format($totalEstimadoAdeudado, 0, ',', '.')); ?></span>
            </div>
        <?php endif; ?>
        <div class="overflow-x-auto mt-4">
            <table class="sg-tabla">
                <thead>
                    <tr>
                        <th>Período</th>
                        <th>Concepto</th>
                        <th>Monto</th>
                        <th>Recargo</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th>Fecha de pago</th>
                    </tr>
                </thead>
                <tbody class="sg-filas">
                    <?php $__empty_1 = true; $__currentLoopData = $cuotasOrdenadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-slate-500"><?php echo e($cuota->mes->nombre_mes); ?> <?php echo e($cuota->anioLectivo->anio); ?></td>
                            <td class="text-slate-500"><?php echo e($cuota->concepto ?: '—'); ?></td>
                            <td class="font-medium text-slate-700">$ <?php echo e(number_format($cuota->monto, 0, ',', '.')); ?></td>
                            <td>
                                <?php if($cuota->recargo > 0): ?>
                                    <span class="sg-badge sg-badge--amarillo sg-badge--sin-punto">+$ <?php echo e(number_format($cuota->recargo, 0, ',', '.')); ?></span>
                                <?php else: ?>
                                    <span class="text-slate-300">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="font-display font-bold text-[#0B3D91]">$ <?php echo e(number_format($cuota->montoTotal(), 0, ',', '.')); ?></td>
                            <td>
                                <?php if($cuota->pagado): ?>
                                    <span class="sg-badge sg-badge--verde">Pagada</span>
                                <?php elseif($cuota->vencida): ?>
                                    <span class="sg-badge sg-badge--rojo">Vencida</span>
                                <?php else: ?>
                                    <span class="sg-badge sg-badge--amarillo">Pendiente</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-slate-500"><?php echo e($cuota->fecha_pago ? \App\Support\FechaEsp::corta($cuota->fecha_pago) : '—'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'banknotes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'banknotes']); ?>Todavía no se generó ninguna cuota para este alumno. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.tarjeta','data' => ['titulo' => 'Historial académico','subtitulo' => 'Solo consulta — para cargar o corregir una materia, usá \'Cargar historial previo\' desde Alumnos','icono' => 'book','class' => 'mb-6','cuerpo' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.tarjeta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Historial académico','subtitulo' => 'Solo consulta — para cargar o corregir una materia, usá \'Cargar historial previo\' desde Alumnos','icono' => 'book','class' => 'mb-6','cuerpo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
        <div class="px-5 pt-4 pb-3 grid sm:grid-cols-2 gap-x-6 gap-y-1.5 text-sm border-b border-slate-100">
            <div class="flex justify-between gap-3"><dt class="text-slate-400">Carrera</dt><dd class="text-slate-700 font-medium text-right"><?php echo e($inscripcion?->carrera?->nombre_carrera ?? '—'); ?></dd></div>
            <div class="flex justify-between gap-3"><dt class="text-slate-400">Resolución del plan de estudios</dt><dd class="text-slate-700 font-medium text-right"><?php echo e($inscripcion?->carrera?->resolucion_ministerial ?? '—'); ?></dd></div>
            <div class="flex justify-between gap-3"><dt class="text-slate-400">DNI</dt><dd class="text-slate-700 font-medium text-right"><?php echo e($alumno->dni); ?></dd></div>
            <div class="flex justify-between gap-3"><dt class="text-slate-400">Año de ingreso a la carrera</dt><dd class="text-slate-700 font-medium text-right"><?php echo e($anioIngreso ?? '—'); ?></dd></div>
        </div>

        <?php if($alumno->historialAlumno->isEmpty()): ?>
            <div class="p-5"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'book']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'book']); ?>Sin historial académico cargado. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="sg-tabla">
                    <thead>
                        <tr>
                            <th>Materia</th>
                            <th>Condición</th>
                            <th class="sg-num">Nota</th>
                            <th>Fecha</th>
                            <th>Libro / Folio</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $alumno->historialAlumno->sortBy('materia.nombre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $condicionNombre = $historial->condicion->nombre_condicion ?? '—';
                                $aprobada = \App\Models\CondicionAlumno::esAprobada($condicionNombre);
                                $acta = $actasPorMateria->get($historial->id_materia);
                            ?>
                            <tr>
                                <td>
                                    <span class="flex items-center gap-2.5 min-w-0">
                                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                                'h-2 w-2 rounded-full shrink-0',
                                                'bg-emerald-500' => $aprobada,
                                                'bg-amber-400' => $condicionNombre === 'Regular' && ! $historial->regularidad_vencida,
                                                'bg-rose-500' => $historial->regularidad_vencida || $condicionNombre === 'Libre',
                                                'bg-slate-300' => $condicionNombre === 'Pendiente',
                                                'bg-sky-500' => $condicionNombre === 'Cursando',
                                            ]) ?>"></span>
                                        <span class="font-semibold text-slate-700"><?php echo e($historial->materia->nombre); ?></span>
                                    </span>
                                </td>
                                <td>
                                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                            'sg-badge',
                                            'sg-badge--verde' => $aprobada,
                                            'sg-badge--amarillo' => $condicionNombre === 'Regular' && ! $historial->regularidad_vencida,
                                            'sg-badge--rojo' => $historial->regularidad_vencida || $condicionNombre === 'Libre',
                                            'sg-badge--gris' => $condicionNombre === 'Pendiente',
                                            'sg-badge--azul' => $condicionNombre === 'Cursando',
                                        ]) ?>">
                                        <?php echo e($historial->regularidad_vencida ? 'Venció' : $condicionNombre); ?>

                                    </span>
                                    <?php if($condicionNombre === 'Regular' && $historial->fecha_limite_calculada): ?>
                                        <p class="text-[11px] text-slate-400 mt-1"><?php echo e($historial->regularidad_vencida ? 'venció el' : 'vence'); ?> <?php echo e(\App\Support\FechaEsp::corta($historial->fecha_limite_calculada)); ?></p>
                                    <?php endif; ?>
                                    <?php if($condicionNombre === 'Equivalencia' && ($historial->institucion_equivalencia || $historial->resolucion_equivalencia)): ?>
                                        <p class="text-[11px] text-slate-400 mt-1">
                                            <?php echo e($historial->institucion_equivalencia ?: '—'); ?>

                                            <?php if($historial->resolucion_equivalencia): ?>
                                                · Res. <?php echo e($historial->resolucion_equivalencia); ?>

                                            <?php endif; ?>
                                        </p>
                                    <?php endif; ?>
                                </td>
                                <td class="sg-num font-semibold text-slate-700"><?php echo e($historial->nota_cursada ?? '—'); ?></td>
                                <td class="text-slate-500"><?php echo e($aprobada && $historial->fecha_ultima_modificacion ? \App\Support\FechaEsp::corta($historial->fecha_ultima_modificacion) : '—'); ?></td>
                                <td class="text-slate-500"><?php echo e($acta ? "{$acta->acta->libro}/{$acta->acta->folio}" : '—'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <?php if($alumno->historialAlumno->isNotEmpty()): ?>
            <div class="px-5 py-3 border-t border-slate-100 flex items-center justify-between text-sm bg-slate-50/60">
                <span class="text-slate-500"><?php echo e($materiasAprobadasTotal); ?> de <?php echo e($totalMateriasPlan); ?> materias del plan aprobadas</span>
                <span class="font-display font-bold text-[#0B3D91]"><?php echo e($porcentajeAvance); ?>% de avance</span>
            </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.tarjeta','data' => ['titulo' => 'Ficha de inscripción','subtitulo' => 'Datos que completó el alumno desde su portal — solo consulta, la edición la hace el propio alumno','icono' => 'document','tono' => 'azul']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.tarjeta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Ficha de inscripción','subtitulo' => 'Datos que completó el alumno desde su portal — solo consulta, la edición la hace el propio alumno','icono' => 'document','tono' => 'azul']); ?>
        <?php $algunaRespuesta = $fichaRespuestas->isNotEmpty(); ?>
        <?php if(! $algunaRespuesta): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'document']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'document']); ?>El alumno todavía no completó su ficha de inscripción. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php else: ?>
            <div class="grid md:grid-cols-2 gap-x-8 gap-y-5">
                <?php $__currentLoopData = $fichaSecciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($seccion->campos->isEmpty()) continue; ?>
                    <div>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-wide mb-2"><?php echo e($seccion->nombre); ?></p>
                        <dl class="text-sm space-y-2 text-slate-500">
                            <?php $__currentLoopData = $seccion->campos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex justify-between gap-4">
                                    <dt class="shrink-0"><?php echo e($campo->etiqueta); ?></dt>
                                    <dd class="text-slate-700 text-right"><?php echo e($fichaRespuestas->get($campo->id_campo)?->valor ?? '—'); ?></dd>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </dl>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/admin/alumnos/show.blade.php ENDPATH**/ ?>