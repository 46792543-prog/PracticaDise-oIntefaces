<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->make('partials.session-guard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('titulo', 'Panel de Secretaría'); ?> · Instituto Superior San Gregorio</title>
    <?php echo $__env->make('partials.tema-sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.validacion-inputs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.mantener-scroll', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="text-slate-800">
    <div class="flex min-h-screen">
        <?php echo $__env->make('partials.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="sg-velo fixed inset-0 z-50 bg-[#04153A]/50 backdrop-blur-sm" data-sg-menu-cerrar></div>

        <div class="flex-1 flex flex-col min-w-0">
            <?php echo $__env->make('partials.sistema-topbar', [
                'seccion' => 'Secretaría',
                'titulo' => $__env->yieldContent('titulo', 'Panel de Secretaría'),
                'conCorte' => true,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="sg-contenido flex-1 px-4 py-6 sm:px-6 lg:px-9 lg:py-8">
                <div class="max-w-[1400px] mx-auto sg-aparecer">
                    <?php if (! empty(trim($__env->yieldContent('header')))): ?>
                        <?php echo $__env->make('partials.sistema-encabezado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                    <?php echo $__env->make('partials.sistema-alertas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->yieldContent('contenido'); ?>
                </div>
            </main>
        </div>
    </div>

    <?php echo $__env->make('partials.guia-asistente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/layouts/admin.blade.php ENDPATH**/ ?>