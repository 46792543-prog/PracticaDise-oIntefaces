

<?php $__env->startSection('titulo', 'Nueva mesa de examen'); ?>
<?php $__env->startSection('subtitulo', 'Gestión académica / Configurar mesa'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Nueva mesa de examen','subtitulo' => 'Gestión académica · Configurar mesa','eyebrow' => 'Mesas de examen','icono' => 'clipboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Nueva mesa de examen','subtitulo' => 'Gestión académica · Configurar mesa','eyebrow' => 'Mesas de examen','icono' => 'clipboard']); ?>
        <a href="<?php echo e(route('admin.mesas.index')); ?>" class="sg-btn sg-btn--borde"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'arrow-left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'arrow-left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Volver</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php
        $meses = [1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril', 5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto', 9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre'];
    ?>

    <?php if($corteActivo): ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'sg-aviso mb-6 sg-revelar',
                'sg-aviso--error' => $corteActivo->anio != now()->year,
                'sg-aviso--alerta' => $corteActivo->anio == now()->year,
            ]) ?>">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'alert','class' => 'h-5 w-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'alert','class' => 'h-5 w-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <span>
                Esta mesa se va a crear en el <strong>año lectivo <?php echo e($corteActivo->anio); ?></strong><?php echo e($corteActivo->estadoAnio?->nombre_estado !== 'Activo' ? ' (Cerrado)' : ''); ?>.
                <?php if($corteActivo->anio != now()->year): ?>
                    Estás en <?php echo e(now()->year); ?> pero el año lectivo activo es <?php echo e($corteActivo->anio); ?>: si no es el año que querés cargar, cambialo arriba con el selector de año lectivo antes de guardar.
                <?php else: ?>
                    Verificá que sea el año correcto antes de guardar.
                <?php endif; ?>
            </span>
        </div>
    <?php endif; ?>

    <div class="grid gap-6 xl:grid-cols-3 items-start">
    <div class="sg-card sg-revelar xl:col-span-2">
        <div class="sg-card__head">
            <div class="sg-card__titulo">
                <span class="sg-chip sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <div><h3>Completar datos de la mesa</h3><p>Los campos con * son obligatorios</p></div>
            </div>
        </div>
        <div class="sg-card__body">

        <form method="POST" action="<?php echo e(route('admin.mesas.store')); ?>" class="space-y-5" id="form-mesa">
            <?php echo csrf_field(); ?>
            <div class="flex items-center gap-3 pt-2">
                <span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'book']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'book']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <p class="font-display font-bold text-sm text-slate-800">Materia</p>
                <span class="h-px flex-1 bg-gradient-to-r from-slate-200 to-transparent"></span>
            </div>
            <div>
                <label class="sg-label">SELECCIONAR MATERIA *</label>
                <select name="id_materia" required class="sg-input w-full">
                    <option value="">Ej: Fundamentos de Enfermería Básica y Comunitaria</option>
                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <optgroup label="<?php echo e($carrera->nombre_carrera); ?>">
                            <?php $__currentLoopData = $carrera->materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($materia->id_materia); ?>"><?php echo e($materia->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </optgroup>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="flex items-center gap-3 pt-2">
                <span class="sg-chip sg-chip--chico sg-chip--celeste"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'calendar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'calendar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <p class="font-display font-bold text-sm text-slate-800">Fechas</p>
                <span class="h-px flex-1 bg-gradient-to-r from-slate-200 to-transparent"></span>
            </div>
            <div class="grid sm:grid-cols-2 gap-4">
                <div>
                    <label class="sg-label">APERTURA DE INSCRIPCIÓN *</label>
                    <input type="date" name="fecha_inicio_inscripcion" id="fecha_inicio_inscripcion" required class="sg-input w-full">
                </div>
                <div>
                    <label class="sg-label">CIERRE DE INSCRIPCIÓN *</label>
                    <input type="date" name="fecha_fin_inscripcion" id="fecha_fin_inscripcion" required class="sg-input w-full">
                </div>
            </div>

            <div>
                <label class="sg-label">FECHA DEL EXAMEN *</label>
                <input type="date" name="fecha_examen" id="fecha_examen" required class="sg-input w-full sm:w-64">
                <p class="sg-ayuda">Debe ser al menos una semana después de la apertura de inscripción.</p>
            </div>

            <div class="flex items-center gap-3 pt-2">
                <span class="sg-chip sg-chip--chico sg-chip--amarillo"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'settings']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <p class="font-display font-bold text-sm text-slate-800">Organización</p>
                <span class="h-px flex-1 bg-gradient-to-r from-slate-200 to-transparent"></span>
            </div>
            <div class="grid sm:grid-cols-2 gap-4">
                <div>
                    <label class="sg-label">TURNO EXAMEN *</label>
                    <div class="flex gap-2">
                        <select name="id_turno" id="id_turno" required class="sg-input min-w-0 flex-1">
                            <option value="">Seleccionar...</option>
                            <?php $__currentLoopData = $turnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t->id_turno); ?>" data-mes-desde="<?php echo e($t->mes_desde); ?>" data-mes-hasta="<?php echo e($t->mes_hasta); ?>"><?php echo e($t->nombre_turno); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="button" onclick="abrirModalTurnos()" title="Gestionar turnos de examen"
                                class="shrink-0 w-[46px] flex items-center justify-center rounded-xl bg-blue-100 text-[#0B3D91] hover:bg-[#0B3D91] hover:text-white transition-colors"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                    </div>
                    <p class="sg-ayuda">Se sugiere solo al elegir la fecha del examen; podés cambiarlo a mano.</p>
                </div>
                <div>
                    <label class="sg-label">CUPO MÁXIMO (OPCIONAL)</label>
                    <input type="number" name="cupo_maximo" min="1" placeholder="Sin límite" class="sg-input w-full">
                </div>
            </div>

            <div>
                <label class="sg-label">LLAMADO *</label>
                <div class="flex gap-2 w-full sm:w-64">
                    <select name="id_llamado" id="id_llamado" required class="sg-input min-w-0 flex-1">
                        <option value="">Seleccionar...</option>
                        <?php $__currentLoopData = $llamados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($l->id_llamado); ?>"><?php echo e($l->nombre_llamado); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button type="button" onclick="abrirModalLlamados()" title="Gestionar llamados"
                            class="shrink-0 w-[46px] flex items-center justify-center rounded-xl bg-blue-100 text-[#0B3D91] hover:bg-[#0B3D91] hover:text-white transition-colors"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                </div>
            </div>

            <div class="flex items-center gap-3 pt-2">
                <span class="sg-chip sg-chip--chico sg-chip--violeta"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'users']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <p class="font-display font-bold text-sm text-slate-800">Tribunal examinador</p>
                <span class="h-px flex-1 bg-gradient-to-r from-slate-200 to-transparent"></span>
            </div>
            <div>
                <label class="sg-label">TRIBUNAL EXAMINADOR (PRESIDENTE / VOCALES / SUPLENTE)</label>
                <div class="grid sm:grid-cols-4 gap-3">
                    <select name="presidente_id" id="presidente_id" class="sg-input tribunal-select w-full">
                        <option value="">Presidente...</option>
                        <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($profesor->id_profesor); ?>"><?php echo e($profesor->apellido); ?>, <?php echo e($profesor->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select name="vocal1_id" id="vocal1_id" class="sg-input tribunal-select w-full">
                        <option value="">Vocal 1...</option>
                        <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($profesor->id_profesor); ?>"><?php echo e($profesor->apellido); ?>, <?php echo e($profesor->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select name="vocal2_id" id="vocal2_id" class="sg-input tribunal-select w-full">
                        <option value="">Vocal 2...</option>
                        <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($profesor->id_profesor); ?>"><?php echo e($profesor->apellido); ?>, <?php echo e($profesor->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select name="suplente_id" id="suplente_id" class="sg-input tribunal-select w-full">
                        <option value="">Suplente...</option>
                        <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($profesor->id_profesor); ?>"><?php echo e($profesor->apellido); ?>, <?php echo e($profesor->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <p id="error-tribunal" class="hidden text-xs font-semibold text-red-500 mt-2">No se puede asignar el mismo docente en más de un rol del tribunal.</p>
            </div>

            <div class="flex justify-end gap-3 pt-5 border-t border-slate-100">
                <a href="<?php echo e(route('admin.mesas.index')); ?>" class="sg-btn sg-btn--borde">Cancelar</a>
                <button type="submit" class="sg-btn sg-btn--primario"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'check']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'check']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Crear mesa</button>
            </div>
        </form>
        </div>
    </div>

    <aside class="sg-card sg-revelar p-6 xl:sticky xl:top-24 bg-gradient-to-br from-blue-50 to-white">
        <span class="sg-chip sg-chip--marca sg-chip--grande mb-4"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
        <h3 class="font-display font-bold text-slate-800 mb-3">Cómo armar la mesa</h3>
        <ol class="space-y-3 text-sm text-slate-600">
            <li class="flex gap-3"><span class="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#0B3D91] text-[11px] font-bold text-white">1</span> Elegí la materia de la carrera.</li>
            <li class="flex gap-3"><span class="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#0B3D91] text-[11px] font-bold text-white">2</span> El examen debe ser al menos una semana después de abrir la inscripción.</li>
            <li class="flex gap-3"><span class="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#0B3D91] text-[11px] font-bold text-white">3</span> El turno se sugiere solo según el mes del examen.</li>
            <li class="flex gap-3"><span class="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#0B3D91] text-[11px] font-bold text-white">4</span> Un mismo docente no puede ocupar dos roles del tribunal.</li>
        </ol>
    </aside>
    </div>

    <?php echo $__env->make('admin.mesas._modales-turnos-llamados', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        // Fecha mínima del examen: apertura de inscripción + 1 semana.
        const inputApertura = document.getElementById('fecha_inicio_inscripcion');
        const inputExamen = document.getElementById('fecha_examen');
        inputApertura.addEventListener('change', function () {
            if (!this.value) return;
            const minimo = new Date(this.value + 'T00:00:00');
            minimo.setDate(minimo.getDate() + 7);
            inputExamen._flatpickr.set('minDate', minimo);
        });

        // Sugerir turno de examen automáticamente según el mes de la fecha del examen.
        const selectTurno = document.getElementById('id_turno');
        inputExamen.addEventListener('change', function () {
            if (!this.value) return;
            const mes = parseInt(this.value.split('-')[1], 10);

            for (const opcion of selectTurno.options) {
                const desde = parseInt(opcion.dataset.mesDesde, 10);
                const hasta = parseInt(opcion.dataset.mesHasta, 10);
                if (!desde || !hasta) continue;

                const coincide = desde <= hasta
                    ? (mes >= desde && mes <= hasta)
                    : (mes >= desde || mes <= hasta);

                if (coincide) {
                    selectTurno.value = opcion.value;
                    break;
                }
            }
        });

        // Tribunal: no permitir el mismo docente en más de un rol.
        const selectsTribunal = document.querySelectorAll('.tribunal-select');
        const errorTribunal = document.getElementById('error-tribunal');
        function hayDuplicados() {
            const valores = Array.from(selectsTribunal).map(s => s.value).filter(v => v !== '');
            return new Set(valores).size !== valores.length;
        }
        function chequearTribunal() {
            const duplicado = hayDuplicados();
            errorTribunal.classList.toggle('hidden', !duplicado);
            selectsTribunal.forEach(s => s.classList.toggle('border-red-400', duplicado));
            return duplicado;
        }
        selectsTribunal.forEach(s => s.addEventListener('change', chequearTribunal));

        document.getElementById('form-mesa').addEventListener('submit', function (e) {
            if (chequearTribunal()) {
                e.preventDefault();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/admin/mesas/create.blade.php ENDPATH**/ ?>