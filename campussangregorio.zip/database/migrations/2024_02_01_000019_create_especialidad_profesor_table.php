<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('especialidad_profesor', function (Blueprint $table) {
            $table->id('id_especialidad');
            $table->string('nombre_especialidad', 45)->unique();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('especialidad_profesor');
    }
};
