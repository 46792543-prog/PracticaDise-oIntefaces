

<?php $__env->startSection('titulo', 'Inscripción a cursada'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Inscripción a cursada','subtitulo' => 'Habilitá, por carrera, los períodos en los que los alumnos pueden inscribirse a cursar','eyebrow' => 'Gestión académica','icono' => 'cap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Inscripción a cursada','subtitulo' => 'Habilitá, por carrera, los períodos en los que los alumnos pueden inscribirse a cursar','eyebrow' => 'Gestión académica','icono' => 'cap']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if(! $anioLectivo): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.tarjeta','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.tarjeta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'calendar','titulo' => 'Sin año lectivo activo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'calendar','titulo' => 'Sin año lectivo activo']); ?>No hay ningún año lectivo marcado como "Activo". Activá uno para poder habilitar la inscripción a cursada. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php elseif(! $carrera): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.tarjeta','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.tarjeta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'cap','titulo' => 'Sin carreras']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'cap','titulo' => 'Sin carreras']); ?>Todavía no hay carreras cargadas. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php else: ?>
        <form method="GET" class="sg-card sg-revelar flex flex-wrap items-end gap-4 px-6 py-5 mb-6">
            <input type="hidden" name="id_anio_cursada" value="<?php echo e($anioCursadaSeleccionada->id_anio_cursada); ?>">
            <div class="flex-1 min-w-[260px]">
                <label class="sg-label" for="id_carrera">Carrera</label>
                <select name="id_carrera" id="id_carrera" onchange="this.form.submit()" class="sg-input w-full">
                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($opcion->id_carrera); ?>" <?php if($opcion->id_carrera === $carrera->id_carrera): echo 'selected'; endif; ?>><?php echo e($opcion->nombre_carrera); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <noscript><button class="sg-btn sg-btn--azul">Ver</button></noscript>
        </form>

        <div class="sg-aviso sg-aviso--info mb-6 sg-revelar">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'info','class' => 'h-5 w-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'info','class' => 'h-5 w-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <span>Habilitá los períodos en los que los alumnos de <strong><?php echo e($carrera->nombre_carrera); ?></strong> van a poder inscribirse a cursar materias del año lectivo <strong><?php echo e($anioLectivo->anio); ?></strong> — elegí el año del plan dentro de cada tarjeta. Las demás carreras no se modifican.</span>
        </div>

        <div class="grid sm:grid-cols-3 gap-5" data-sg-escalonar>
            <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sg-card sg-card--hover p-6 overflow-hidden" data-cursada-tarjeta>
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <p class="sg-eyebrow mb-1">Período</p>
                            <p class="font-display font-bold text-lg text-slate-800"><?php echo e($periodo->nombre_periodo); ?></p>
                        </div>
                        <select class="sg-input sg-input--chico w-auto" data-cursada-selector-anio>
                            <?php $__currentLoopData = $periodo->habilitacionesPorAnio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item['anioCursada']->id_anio_cursada); ?>" <?php if($item['anioCursada']->id_anio_cursada === $periodo->anioCursadaPorDefecto->id_anio_cursada): echo 'selected'; endif; ?>><?php echo e($item['anioCursada']->nombre_anio); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <?php $__currentLoopData = $periodo->habilitacionesPorAnio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $abierto = $item['habilitacion']->abierto ?? false; ?>
                        <div data-cursada-panel-anio="<?php echo e($item['anioCursada']->id_anio_cursada); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['hidden' => $item['anioCursada']->id_anio_cursada !== $periodo->anioCursadaPorDefecto->id_anio_cursada]) ?>">
                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['absolute inset-x-0 top-0 h-1', 'bg-gradient-to-r from-emerald-400 to-emerald-600' => $abierto, 'bg-slate-200' => ! $abierto]) ?>"></span>
                            <div class="flex items-center justify-between mb-5">
                                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sg-chip sg-chip--grande', 'sg-chip--verde' => $abierto, 'sg-chip--gris' => ! $abierto]) ?>">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => $abierto ? 'check-circle' : 'lock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($abierto ? 'check-circle' : 'lock')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </span>
                                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sg-badge', 'sg-badge--verde' => $abierto, 'sg-badge--gris' => ! $abierto]) ?>">
                                    <?php echo e($abierto ? 'Abierto' : 'Cerrado'); ?>

                                </span>
                            </div>

                            <div class="mb-5">
                                <p class="sg-eyebrow mb-1.5">Materias de <?php echo e($item['anioCursada']->nombre_anio); ?> · <?php echo e($periodo->nombre_periodo); ?></p>
                                <?php if($item['materias']->isEmpty()): ?>
                                    <p class="text-xs text-slate-400">No hay materias cargadas para este año y período.</p>
                                <?php else: ?>
                                    <ul class="text-sm text-slate-600 space-y-1 max-h-40 overflow-y-auto pr-1">
                                        <?php $__currentLoopData = $item['materias']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="flex items-center gap-2">
                                                <span class="h-1.5 w-1.5 rounded-full bg-slate-300 shrink-0"></span>
                                                <?php echo e($materia->nombre); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </div>

                            <form method="POST" action="<?php echo e(route('admin.cursada.toggle', $periodo)); ?>"
                                  onsubmit="return confirm(<?php echo e(\Illuminate\Support\Js::from($abierto
                                        ? '¿Cerrar la inscripción a cursada de ' . $periodo->nombre_periodo . ' (' . $item['anioCursada']->nombre_anio . ') para ' . $carrera->nombre_carrera . '?'
                                        : '¿Abrir la inscripción a cursada de ' . $periodo->nombre_periodo . ' (' . $item['anioCursada']->nombre_anio . ') para ' . $carrera->nombre_carrera . '?')); ?>);">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="id_anio_lectivo" value="<?php echo e($anioLectivo->id_anio_lectivo); ?>">
                                <input type="hidden" name="id_carrera" value="<?php echo e($carrera->id_carrera); ?>">
                                <input type="hidden" name="id_anio_cursada" value="<?php echo e($item['anioCursada']->id_anio_cursada); ?>">
                                <input type="hidden" name="abierto" value="<?php echo e($abierto ? '0' : '1'); ?>">
                                <button type="submit" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sg-btn w-full', 'sg-btn--peligro' => $abierto, 'sg-btn--azul' => ! $abierto]) ?>">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => $abierto ? 'lock' : 'bolt']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($abierto ? 'lock' : 'bolt')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php echo e($abierto ? 'Cerrar inscripción' : 'Abrir inscripción'); ?>

                                </button>
                            </form>

                            <form method="POST" action="<?php echo e(route('admin.cursada.preferencia-anio', $periodo)); ?>" class="mt-2">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="id_carrera" value="<?php echo e($carrera->id_carrera); ?>">
                                <input type="hidden" name="id_anio_cursada" value="<?php echo e($item['anioCursada']->id_anio_cursada); ?>">
                                <button type="submit" class="sg-btn sg-btn--borde w-full">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'check']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'check']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    Guardar <?php echo e($item['anioCursada']->nombre_anio); ?> como vista de esta tarjeta
                                </button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <script>
            const inputAnioCarreraForm = document.querySelector('input[name="id_anio_cursada"]');
            document.querySelectorAll('[data-cursada-tarjeta]').forEach((tarjeta) => {
                const selector = tarjeta.querySelector('[data-cursada-selector-anio]');
                selector?.addEventListener('change', () => {
                    tarjeta.querySelectorAll('[data-cursada-panel-anio]').forEach((panel) => {
                        panel.classList.toggle('hidden', panel.dataset.cursadaPanelAnio !== selector.value);
                    });
                    // Para que, si después cambiás de carrera, se mantenga este mismo año seleccionado.
                    if (inputAnioCarreraForm) inputAnioCarreraForm.value = selector.value;
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/admin/cursada/index.blade.php ENDPATH**/ ?>