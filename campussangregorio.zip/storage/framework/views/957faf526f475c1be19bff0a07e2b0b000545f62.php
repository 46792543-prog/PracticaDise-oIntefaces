

<?php $__env->startSection('titulo', 'Estado de Pagos'); ?>
<?php $__env->startSection('subtitulo', 'Panorama general de alumnos al día y con cuotas pendientes'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Estado de Pagos','subtitulo' => 'Panorama general de alumnos al día y con cuotas pendientes','eyebrow' => 'Finanzas','icono' => 'chart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Estado de Pagos','subtitulo' => 'Panorama general de alumnos al día y con cuotas pendientes','eyebrow' => 'Finanzas','icono' => 'chart']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php $porcentajeAlDia = $totalAlumnos > 0 ? round($alumnosAlDia / $totalAlumnos * 100) : 0; ?>

    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6" data-sg-escalonar>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.stat','data' => ['etiqueta' => 'Alumnos al día','valor' => $alumnosAlDia,'icono' => 'check-circle','tono' => 'verde']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['etiqueta' => 'Alumnos al día','valor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($alumnosAlDia),'icono' => 'check-circle','tono' => 'verde']); ?>
            <span class="text-slate-400 font-medium">de <?php echo e($totalAlumnos); ?> alumnos</span>
            <div class="sg-progreso mt-2"><span style="width: <?php echo e($porcentajeAlDia); ?>%; background: linear-gradient(90deg, #34D399, #059669);"></span></div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.stat','data' => ['etiqueta' => 'Alumnos con deuda','valor' => $alumnosConDeuda,'icono' => 'alert','tono' => 'rojo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['etiqueta' => 'Alumnos con deuda','valor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($alumnosConDeuda),'icono' => 'alert','tono' => 'rojo']); ?>
            <span class="text-slate-400 font-medium">tienen cuotas pendientes</span>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.stat','data' => ['etiqueta' => 'Monto adeudado','valor' => '$ ' . number_format($montoAdeudadoTotal, 0, ',', '.'),'icono' => 'banknotes','tono' => 'azul']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['etiqueta' => 'Monto adeudado','valor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('$ ' . number_format($montoAdeudadoTotal, 0, ',', '.')),'icono' => 'banknotes','tono' => 'azul']); ?>
            <span class="text-slate-400 font-medium">total pendiente de cobro</span>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.stat','data' => ['etiqueta' => 'Cuotas vencidas','valor' => $cuotasVencidas,'icono' => 'clock','tono' => 'amarillo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['etiqueta' => 'Cuotas vencidas','valor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cuotasVencidas),'icono' => 'clock','tono' => 'amarillo']); ?>
            <span class="text-slate-400 font-medium">pasaron la fecha de vencimiento</span>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="sg-card sg-revelar overflow-hidden">
        <div class="sg-card__head">
            <div class="sg-card__titulo">
                <span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'users']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <div><h3>Estado de pagos por alumno</h3><p>Filtrá por nombre, carrera o situación</p></div>
            </div>
        </div>

        <form method="GET" class="flex flex-wrap items-center gap-3 px-6 py-4 border-b border-slate-100 bg-slate-50/60">
            <div class="sg-campo-icono flex-1 min-w-[200px]">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <input type="text" name="q" value="<?php echo e($busqueda); ?>" placeholder="Nombre, apellido o DNI..." maxlength="20"
                       oninput="this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÑÜáéíóúñü0-9\s]/g, '')"
                       class="sg-input w-full">
            </div>

            <select name="carrera" class="sg-input w-auto">
                <option value="">Todas las carreras</option>
                <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($carrera->id_carrera); ?>" <?php if($carreraId == $carrera->id_carrera): echo 'selected'; endif; ?>><?php echo e($carrera->nombre_carrera); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="estado" class="sg-input w-auto">
                <option value="">Todos los estados</option>
                <option value="al_dia" <?php if($estado === 'al_dia'): echo 'selected'; endif; ?>>Al día</option>
                <option value="debe" <?php if($estado === 'debe'): echo 'selected'; endif; ?>>Con deuda</option>
            </select>

            <button class="sg-btn sg-btn--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'filter']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Filtrar</button>
            <?php if($busqueda || $carreraId || $estado): ?>
                <a href="<?php echo e(route('director.pagos.index')); ?>" class="sg-btn sg-btn--borde"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'x']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Limpiar</a>
            <?php endif; ?>
        </form>

        <div class="overflow-x-auto">
        <table class="sg-tabla">
            <thead>
                <tr>
                    <th>Alumno</th>
                    <th>Carrera</th>
                    <th>Pagadas</th>
                    <th>Pendientes</th>
                    <th>Monto adeudado</th>
                    <th>Estado</th>
                    <th class="!text-center">Acción</th>
                </tr>
            </thead>
            <tbody class="sg-filas">
                <?php $__empty_1 = true; $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $adeudado = (float) ($alumno->monto_pendiente ?? 0) + (float) ($alumno->recargo_pendiente ?? 0);
                        $historialPagos = [
                            'alumno' => "{$alumno->apellido}, {$alumno->nombre}",
                            'dni' => $alumno->dni,
                            'cuotas' => $alumno->cuotas->map(fn ($c) => [
                                'periodo' => ($c->mes->nombre_mes ?? '—') . ' ' . ($c->anioLectivo->anio ?? ''),
                                'concepto' => $c->concepto ?: 'Cuota mensual',
                                'total' => '$ ' . number_format($c->montoTotal(), 0, ',', '.'),
                                'recargo' => (float) $c->recargo > 0 ? '$ ' . number_format($c->recargo, 0, ',', '.') : null,
                                'vencimiento' => $c->fecha_vencimiento ? \App\Support\FechaEsp::corta($c->fecha_vencimiento) : '—',
                                'pagado' => (bool) $c->pagado,
                                'vencida' => ! $c->pagado && $c->vencida,
                                'fecha_pago' => $c->fecha_pago ? \App\Support\FechaEsp::corta($c->fecha_pago) : null,
                                'medio' => $c->movimientoCaja?->medioPago?->nombre_medio,
                            ])->values(),
                        ];
                    ?>
                    <tr>
                        <td>
                            <div class="flex items-center gap-3">
                                <span class="sg-avatar">
                                    <?php echo e(mb_substr($alumno->nombre, 0, 1)); ?><?php echo e(mb_substr($alumno->apellido, 0, 1)); ?>

                                </span>
                                <div class="min-w-0">
                                    <p class="font-semibold text-slate-800"><?php echo e($alumno->apellido); ?>, <?php echo e($alumno->nombre); ?></p>
                                    <p class="text-xs text-slate-400">DNI <?php echo e($alumno->dni); ?></p>
                                </div>
                            </div>
                        </td>
                        <td><?php echo e($alumno->inscripcionesCarrera->first()?->carrera?->nombre_carrera ?? '—'); ?></td>
                        <td><span class="inline-grid min-w-[2rem] h-8 place-items-center rounded-lg bg-emerald-50 px-2 font-display font-bold text-emerald-600"><?php echo e($alumno->cuotas_pagadas_count); ?></span></td>
                        <td><span class="inline-grid min-w-[2rem] h-8 place-items-center rounded-lg px-2 font-display font-bold <?php echo e($alumno->cuotas_pendientes_count > 0 ? 'bg-rose-50 text-rose-600' : 'bg-slate-50 text-slate-400'); ?>"><?php echo e($alumno->cuotas_pendientes_count); ?></span></td>
                        <td class="font-display font-bold !text-slate-800 whitespace-nowrap">
                            <?php echo e($adeudado > 0 ? '$ ' . number_format($adeudado, 0, ',', '.') : '—'); ?>

                        </td>
                        <td>
                            <?php if($alumno->cuotas_pendientes_count > 0): ?>
                                <span class="sg-badge sg-badge--rojo">Debe</span>
                            <?php else: ?>
                                <span class="sg-badge sg-badge--verde">Al día</span>
                            <?php endif; ?>
                        </td>
                        <td class="!text-center">
                            <button type="button" onclick="verHistorialPagos(<?php echo e(\Illuminate\Support\Js::from($historialPagos)); ?>)"
                                    class="sg-btn sg-btn--borde sg-btn--icono" title="Ver historial de pagos" aria-label="Ver historial de pagos de <?php echo e($alumno->apellido); ?>, <?php echo e($alumno->nombre); ?>">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'eye']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'eye']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'search','titulo' => 'Sin resultados']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'search','titulo' => 'Sin resultados']); ?>No se encontraron alumnos con esos filtros. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
        <?php if($alumnos->hasPages()): ?>
            <div class="sg-card__foot"><?php echo e($alumnos->links()); ?></div>
        <?php endif; ?>
    </div>

    
    <div id="modal-historial-pagos" class="hidden fixed inset-0 bg-[#04153A]/50 backdrop-blur-sm z-[70] items-center justify-center p-4" onclick="if (event.target === this) cerrarHistorialPagos()">
        <div class="sg-modal bg-white rounded-3xl shadow-2xl ring-1 ring-slate-200/60 w-full max-w-4xl p-6 max-h-[88vh] flex flex-col">
            <div class="flex items-start justify-between gap-4 mb-4">
                <div class="flex items-center gap-3 min-w-0">
                    <span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'clock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'clock']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                    <div class="min-w-0">
                        <h3 class="font-display font-bold text-slate-800">Historial de pagos</h3>
                        <p class="text-sm text-slate-500 truncate" id="historial-alumno"></p>
                    </div>
                </div>
                <button type="button" onclick="cerrarHistorialPagos()" class="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors" aria-label="Cerrar"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'x']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
            </div>

            <div class="grid grid-cols-3 gap-3 mb-4">
                <div class="rounded-2xl bg-emerald-50 px-4 py-3 text-center"><p class="font-display font-bold text-xl text-emerald-600" id="historial-pagadas">0</p><p class="text-xs font-semibold text-emerald-700">Pagadas</p></div>
                <div class="rounded-2xl bg-amber-50 px-4 py-3 text-center"><p class="font-display font-bold text-xl text-amber-600" id="historial-pendientes">0</p><p class="text-xs font-semibold text-amber-700">Pendientes</p></div>
                <div class="rounded-2xl bg-rose-50 px-4 py-3 text-center"><p class="font-display font-bold text-xl text-rose-600" id="historial-vencidas">0</p><p class="text-xs font-semibold text-rose-700">Vencidas</p></div>
            </div>

            <div class="overflow-auto rounded-2xl border border-slate-100">
                <table class="sg-tabla">
                    <thead>
                        <tr>
                            <th>Período</th>
                            <th>Concepto</th>
                            <th>Vencimiento</th>
                            <th class="!text-right">Monto</th>
                            <th>Estado</th>
                            <th>Pagada el</th>
                        </tr>
                    </thead>
                    <tbody id="historial-filas"></tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function escaparHtml(texto) {
            const div = document.createElement('div');
            div.textContent = texto ?? '';
            return div.innerHTML;
        }

        function verHistorialPagos(datos) {
            document.getElementById('historial-alumno').textContent = datos.alumno + ' · DNI ' + datos.dni;
            document.getElementById('historial-pagadas').textContent = datos.cuotas.filter((c) => c.pagado).length;
            document.getElementById('historial-pendientes').textContent = datos.cuotas.filter((c) => ! c.pagado).length;
            document.getElementById('historial-vencidas').textContent = datos.cuotas.filter((c) => c.vencida).length;

            const filas = datos.cuotas.map((c) => {
                const estado = c.pagado
                    ? '<span class="sg-badge sg-badge--verde">Pagada</span>'
                    : (c.vencida ? '<span class="sg-badge sg-badge--rojo">Vencida</span>' : '<span class="sg-badge sg-badge--amarillo">Pendiente</span>');
                const pago = c.pagado
                    ? escaparHtml(c.fecha_pago ?? '—') + (c.medio ? '<p class="text-xs text-slate-400">' + escaparHtml(c.medio) + '</p>' : '')
                    : '—';
                const recargo = c.recargo ? '<p class="text-xs font-normal text-slate-400">incluye recargo ' + escaparHtml(c.recargo) + '</p>' : '';

                return '<tr>'
                    + '<td class="font-semibold !text-slate-800 whitespace-nowrap">' + escaparHtml(c.periodo) + '</td>'
                    + '<td>' + escaparHtml(c.concepto) + '</td>'
                    + '<td class="whitespace-nowrap">' + escaparHtml(c.vencimiento) + '</td>'
                    + '<td class="!text-right font-display font-bold !text-slate-800 whitespace-nowrap">' + escaparHtml(c.total) + recargo + '</td>'
                    + '<td>' + estado + '</td>'
                    + '<td class="whitespace-nowrap">' + pago + '</td>'
                    + '</tr>';
            });

            document.getElementById('historial-filas').innerHTML = filas.length
                ? filas.join('')
                : '<tr><td colspan="6" class="!text-center text-slate-400 py-8">Este alumno todavía no tiene cuotas generadas.</td></tr>';

            const modal = document.getElementById('modal-historial-pagos');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function cerrarHistorialPagos() {
            const modal = document.getElementById('modal-historial-pagos');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }

        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') cerrarHistorialPagos(); });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.director', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/director/pagos/index.blade.php ENDPATH**/ ?>