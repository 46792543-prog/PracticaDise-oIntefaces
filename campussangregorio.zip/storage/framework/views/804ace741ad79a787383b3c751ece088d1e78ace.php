
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['saludo', 'etiqueta' => 'Instituto Superior San Gregorio']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['saludo', 'etiqueta' => 'Instituto Superior San Gregorio']); ?>
<?php foreach (array_filter((['saludo', 'etiqueta' => 'Instituto Superior San Gregorio']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<section <?php echo e($attributes->merge(['class' => 'sg-hero mb-8 sg-revelar'])); ?>>
    <span class="sg-hero__puntos"></span>
    <span class="sg-hero__blob sg-hero__blob--celeste"></span>
    <span class="sg-hero__blob sg-hero__blob--amarillo"></span>
    <span class="sg-hero__blob sg-hero__blob--anillo"></span>
    <div class="px-6 sm:px-9 py-8 sm:py-9">
        <div class="flex items-start justify-between gap-6 flex-wrap">
            <div class="min-w-0">
                <span class="sg-hero__tag"><span class="h-1.5 w-1.5 rounded-full bg-[#FFC107]"></span><?php echo e($etiqueta); ?></span>
                <h1 class="sg-hero__saludo mt-4"><?php echo $saludo; ?></h1>
                <div class="mt-2 text-sm text-blue-100/85"><?php echo e($slot); ?></div>
            </div>
            <?php if(isset($acciones)): ?>
                <div class="flex items-center gap-3 flex-wrap"><?php echo e($acciones); ?></div>
            <?php endif; ?>
        </div>
        <?php if(isset($extra)): ?>
            <div class="mt-7 grid gap-3 grid-cols-2 xl:grid-cols-4"><?php echo e($extra); ?></div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/components/sg/hero.blade.php ENDPATH**/ ?>