

<?php $__env->startSection('titulo', 'Configuración Institucional'); ?>
<?php $__env->startSection('subtitulo', 'Datos generales de la institución, usados en actas y documentación oficial'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Configuración Institucional','subtitulo' => 'Datos generales de la institución, usados en actas y documentación oficial','eyebrow' => 'Ajustes','icono' => 'settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Configuración Institucional','subtitulo' => 'Datos generales de la institución, usados en actas y documentación oficial','eyebrow' => 'Ajustes','icono' => 'settings']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="sg-card sg-revelar overflow-hidden mb-8">
        <div class="sg-card__head">
            <div class="sg-card__titulo">
                <span class="sg-chip sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'building']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'building']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <div><h3>Datos de la institución</h3><p>Se usan en actas, certificados y en la página pública</p></div>
            </div>
        </div>

        <div class="p-6">
            <form method="POST" action="<?php echo e(route('director.configuracion.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-6 flex items-center gap-5 rounded-2xl bg-gradient-to-r from-blue-50 to-white border border-blue-100 p-4">
                    <div id="logo-preview-wrap" class="h-20 w-20 shrink-0 rounded-2xl bg-gradient-to-br from-[#4FC3F7] to-[#0B3D91] shadow-lg ring-4 ring-white outline outline-2 outline-[#FFC107] overflow-hidden grid place-items-center">
                        <img id="logo-preview" src="<?php echo e($configuracion?->logo_url); ?>" alt="Logo institucional" class="<?php echo e($configuracion?->logo_url ? '' : 'hidden'); ?> h-full w-full object-cover">
                        <svg id="logo-preview-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.7" class="<?php echo e($configuracion?->logo_url ? 'hidden' : ''); ?> h-8 w-8">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 2.25 4.5 5.4v5.4c0 5.13 3.24 9.6 7.5 10.95 4.26-1.35 7.5-5.82 7.5-10.95V5.4L12 2.25Z" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="m9 12 2.25 2.25L15.5 9.5" />
                        </svg>
                    </div>
                    <div>
                        <label class="sg-label">LOGO DE LA INSTITUCIÓN</label>
                        <input type="file" id="logo-input" name="logo" accept="image/png,image/jpeg,image/webp"
                               class="block w-full text-xs text-slate-500 file:mr-3 file:rounded-xl file:border-0 file:bg-[#0B3D91] file:text-white file:px-4 file:py-2 file:text-xs file:font-bold file:cursor-pointer hover:file:bg-[#082A66] file:transition-colors">
                        <p class="text-[11px] text-slate-400 mt-1">JPG, PNG o WEBP. Vas a poder recortarla antes de guardar.</p>
                        <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-[11px] text-red-500 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div id="crop-modal" class="hidden fixed inset-0 z-[70] items-center justify-center bg-[#04153A]/60 backdrop-blur-sm px-4">
                    <div class="sg-modal bg-white rounded-3xl shadow-2xl ring-1 ring-slate-200/60 w-full max-w-lg overflow-hidden">
                        <div class="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
                            <h3 class="font-display font-bold text-slate-800 flex items-center gap-3"><span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'photo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'photo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span> Recortar logo</h3>
                            <button type="button" id="crop-cancel" class="grid h-9 w-9 place-items-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors" aria-label="Cerrar"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'x']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                        </div>
                        <div class="p-4">
                            <div class="max-h-[55vh] overflow-hidden bg-slate-100 rounded-xl">
                                <img id="crop-image" class="block max-w-full" alt="Imagen a recortar">
                            </div>
                            <p class="text-[11px] text-slate-400 mt-2">Arrastrá y ajustá el recuadro para elegir la parte de la imagen que se va a usar como logo.</p>
                        </div>
                        <div class="px-5 py-3.5 border-t border-slate-100 flex justify-end gap-2">
                            <button type="button" id="crop-cancel-2" class="sg-btn sg-btn--borde">Cancelar</button>
                            <button type="button" id="crop-confirm" class="sg-btn sg-btn--azul">Recortar y usar</button>
                        </div>
                    </div>
                </div>

                <div class="grid sm:grid-cols-2 gap-4 mb-4">
                    <div class="sm:col-span-2">
                        <label class="sg-label">NOMBRE DE LA INSTITUCIÓN *</label>
                        <input type="text" name="nombre_institucion" data-solo="letras" data-max-len="40" maxlength="40" required
                               value="<?php echo e(old('nombre_institucion', $configuracion->nombre_institucion ?? '')); ?>"
                               class="sg-input w-full">
                    </div>

                    <div class="sm:col-span-2">
                        <label class="sg-label">DIRECCIÓN</label>
                        <input type="text" name="direccion" data-solo="direccion" data-max-len="100" maxlength="100"
                               value="<?php echo e(old('direccion', $configuracion->direccion ?? '')); ?>"
                               class="sg-input w-full">
                    </div>

                    <div>
                        <label class="sg-label">NOMBRE DEL/LA DIRECTOR/A</label>
                        <input type="text" name="nombre_director" data-solo="letras" data-max-len="20" maxlength="20"
                               value="<?php echo e(old('nombre_director', $configuracion->nombre_director ?? '')); ?>"
                               class="sg-input w-full">
                    </div>

                    <div>
                        <label class="sg-label">TELÉFONO DE CONTACTO</label>
                        <input type="text" name="telefono_contacto" data-solo="numeros" data-max-len="20" maxlength="20"
                               value="<?php echo e(old('telefono_contacto', $configuracion->telefono_contacto ?? '')); ?>"
                               class="sg-input w-full">
                    </div>

                    <div class="sm:col-span-2">
                        <label class="sg-label">EMAIL DE CONTACTO</label>
                        <input type="email" name="email_contacto" maxlength="40"
                               value="<?php echo e(old('email_contacto', $configuracion->email_contacto ?? '')); ?>"
                               class="sg-input w-full">
                    </div>

                    <div class="sm:col-span-2">
                        <label class="sg-label">HORARIOS DE ATENCIÓN</label>
                        <input type="text" name="horario_atencion" maxlength="60" placeholder="Ej: Lunes a viernes, 14:00 a 22:00"
                               value="<?php echo e(old('horario_atencion', $configuracion->horario_atencion ?? '')); ?>"
                               class="sg-input w-full">
                        <p class="text-[11px] text-slate-400 mt-1">Se muestra en la sección "Ubicación" de la página pública (landing).</p>
                    </div>
                </div>

                <div class="rounded-2xl border border-amber-100 bg-gradient-to-r from-amber-50/70 to-white p-5 mt-6 mb-5">
                    <p class="font-display font-bold text-slate-800 flex items-center gap-2 mb-1"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'sparkles','class' => 'h-5 w-5 text-[#F5B000]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'sparkles','class' => 'h-5 w-5 text-[#F5B000]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Números destacados en la landing</p>
                    <p class="text-xs text-slate-500 mb-4">Si dejás un campo vacío, se muestra el dato real calculado por el sistema.</p>
                    <div class="grid sm:grid-cols-4 gap-4">
                        <div>
                            <label class="sg-label">AÑOS DE FORMACIÓN</label>
                            <input type="number" min="0" max="999" name="landing_anios_formacion"
                                   value="<?php echo e(old('landing_anios_formacion', $configuracion->landing_anios_formacion ?? '')); ?>"
                                   placeholder="<?php echo e($carrera->duracion_anos ?? 3); ?>"
                                   class="sg-input w-full">
                        </div>
                        <div>
                            <label class="sg-label">DOCENTES ACTIVOS</label>
                            <input type="number" min="0" max="999" name="landing_docentes_cantidad"
                                   value="<?php echo e(old('landing_docentes_cantidad', $configuracion->landing_docentes_cantidad ?? '')); ?>"
                                   placeholder="<?php echo e($docentesActivos ?? 0); ?>"
                                   class="sg-input w-full">
                        </div>
                        <div>
                            <label class="sg-label">ALUMNOS CURSANDO</label>
                            <input type="number" min="0" max="999" name="landing_alumnos_cantidad"
                                   value="<?php echo e(old('landing_alumnos_cantidad', $configuracion->landing_alumnos_cantidad ?? '')); ?>"
                                   placeholder="<?php echo e($alumnosActivos ?? 0); ?>"
                                   class="sg-input w-full">
                        </div>
                        <div>
                            <label class="sg-label">EGRESADOS</label>
                            <input type="number" min="0" max="999" name="landing_egresados_cantidad"
                                   value="<?php echo e(old('landing_egresados_cantidad', $configuracion->landing_egresados_cantidad ?? '')); ?>"
                                   placeholder="120"
                                   class="sg-input w-full">
                        </div>
                    </div>
                </div>

                <?php if($configuracion?->fecha_ultima_modificacion): ?>
                    <p class="text-xs text-slate-400 mb-4 flex items-center gap-1.5">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'clock','class' => 'h-3.5 w-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'clock','class' => 'h-3.5 w-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Última modificación: <?php echo e(\App\Support\FechaEsp::corta($configuracion->fecha_ultima_modificacion)); ?>

                        <?php if($configuracion->secretarioModifica): ?>
                            por <?php echo e($configuracion->secretarioModifica->apellido); ?>, <?php echo e($configuracion->secretarioModifica->nombre); ?>

                        <?php endif; ?>
                    </p>
                <?php endif; ?>

                <div class="flex justify-end">
                    <button type="submit" class="sg-btn sg-btn--primario"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'check']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'check']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Guardar cambios</button>
                </div>
            </form>

            <?php if($configuracion): ?>
                <form method="POST" action="<?php echo e(route('director.configuracion.destroy')); ?>"
                      onsubmit="return confirm('¿Eliminar los datos institucionales cargados? Esta acción no se puede deshacer.');"
                      class="mt-4 pt-4 border-t border-slate-100 flex justify-end">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="sg-btn sg-btn--peligro"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'trash']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'trash']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Eliminar datos</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="sg-card sg-revelar overflow-hidden mb-8">
        <div class="sg-card__head">
            <div class="sg-card__titulo">
                <span class="sg-chip sg-chip--celeste"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'photo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'photo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <div><h3>Imágenes de portada (landing)</h3><p>Carrusel de fondo de la página pública</p></div>
            </div>
        </div>

        <div class="p-6">
            <p class="text-xs text-slate-500 mb-4">
                Se muestran como carrusel de fondo en la portada de la página pública. Si no cargás ninguna, se usa un fondo de color por defecto.
            </p>

            <form method="POST" action="<?php echo e(route('director.configuracion.imagenes.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label id="zona-arrastrar" for="imagenes-input"
                       class="group flex flex-col items-center justify-center gap-2 rounded-3xl border-2 border-dashed border-slate-200 bg-gradient-to-b from-slate-50 to-white px-6 py-12 text-center cursor-pointer transition hover:border-[#4FC3F7] hover:bg-[#0B3D91]/5">
                    <span class="sg-vacio__icono !mb-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="h-8 w-8">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 16.5V9.75m0 0 3 3m-3-3-3 3M6.75 19.5a4.5 4.5 0 0 1-1.41-8.775 5.25 5.25 0 0 1 10.233-2.33 3 3 0 0 1 3.758 3.848A3.752 3.752 0 0 1 18 19.5H6.75Z" />
                    </svg></span>
                    <p class="text-sm font-semibold text-slate-600">Arrastrá imágenes acá, o hacé clic para elegirlas</p>
                    <p class="text-[11px] text-slate-400">JPG, PNG o WEBP. Podés seleccionar varias a la vez.</p>
                    <input id="imagenes-input" type="file" name="imagenes[]" accept="image/png,image/jpeg,image/webp" multiple class="hidden">
                </label>
                <?php $__errorArgs = ['imagenes.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-[11px] text-red-500 mt-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div id="imagenes-seleccionadas" class="text-xs text-slate-500 mt-2"></div>
                <div class="flex justify-end mt-3">
                    <button type="submit" class="sg-btn sg-btn--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'upload']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'upload']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Subir imágenes</button>
                </div>
            </form>

            <?php if($imagenesLanding->isNotEmpty()): ?>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
                    <?php $__currentLoopData = $imagenesLanding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relative group rounded-2xl overflow-hidden ring-1 ring-slate-200 aspect-video shadow-sm hover:shadow-lg transition-shadow">
                            <img src="<?php echo e($imagen->url); ?>" alt="" class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105">
                            <form method="POST" action="<?php echo e(route('director.configuracion.imagenes.destroy', $imagen)); ?>"
                                  onsubmit="return confirm('¿Eliminar esta imagen de la portada?');"
                                  class="absolute top-1.5 right-1.5">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="h-8 w-8 grid place-items-center rounded-lg bg-white/90 text-red-600 shadow opacity-0 group-hover:opacity-100 transition" title="Eliminar"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'trash','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'trash','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="text-sm text-slate-400 mt-5 text-center">Todavía no cargaste imágenes de portada.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="sg-card sg-revelar overflow-hidden mb-8">
        <div class="sg-card__head">
            <div class="sg-card__titulo">
                <span class="sg-chip sg-chip--amarillo"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'calendar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'calendar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <div><h3>Años lectivos</h3><p>Períodos de trabajo del sistema</p></div>
            </div>
        </div>

        <div class="p-6">
            <form method="POST" action="<?php echo e(route('director.configuracion.cortes.store')); ?>" class="grid sm:grid-cols-[1fr_auto] gap-4 mb-6">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="sg-label">GENERAR NUEVO AÑO LECTIVO *</label>
                    <input type="text" inputmode="numeric" data-solo="numeros" data-max-len="4" maxlength="4" name="anio" placeholder="<?php echo e(now()->year + 1); ?>" required
                           value="<?php echo e(old('anio')); ?>"
                           class="sg-input w-full">
                </div>
                <div class="flex items-end">
                    <button type="submit" class="sg-btn sg-btn--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Generar año lectivo</button>
                </div>
            </form>

            <div class="grid gap-3 sm:grid-cols-2" data-sg-escalonar>
                <?php $__empty_1 = true; $__currentLoopData = $aniosLectivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between rounded-2xl border-[1.5px] px-4 py-3 transition-colors <?php echo e($anio->estadoAnio?->nombre_estado === 'Activo' ? 'border-emerald-200 bg-emerald-50/40' : 'border-slate-100 bg-white'); ?>">
                        <div class="flex items-center gap-3">
                            <span class="grid h-11 w-11 place-items-center rounded-xl <?php echo e($anio->estadoAnio?->nombre_estado === 'Activo' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'); ?> font-display font-extrabold text-xs"><?php echo e(substr($anio->anio, -2)); ?></span>
                            <span class="font-display font-bold text-slate-800">Año lectivo <?php echo e($anio->anio); ?></span>
                            <?php if($anio->estadoAnio?->nombre_estado === 'Activo'): ?>
                                <span class="sg-badge sg-badge--verde">Activo</span>
                            <?php else: ?>
                                <span class="sg-badge sg-badge--gris">Cerrado</span>
                            <?php endif; ?>
                        </div>
                        <div class="flex items-center gap-2">
                            <form method="POST" action="<?php echo e(route('director.configuracion.cortes.estado', $anio)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit" class="sg-btn sg-btn--borde sg-btn--chico">
                                    <?php echo e($anio->estadoAnio?->nombre_estado === 'Activo' ? 'Cerrar' : 'Reactivar'); ?>

                                </button>
                            </form>
                            <form method="POST" action="<?php echo e(route('director.configuracion.cortes.destroy', $anio)); ?>"
                                  onsubmit="return confirm('¿Eliminar el año lectivo <?php echo e($anio->anio); ?>? Sólo se puede eliminar si no tiene datos cargados.');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="h-8 w-8 grid place-items-center rounded-lg text-slate-400 hover:bg-red-50 hover:text-red-600 transition-colors" title="Eliminar año lectivo"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'trash','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'trash','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'calendar','class' => 'sm:col-span-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'calendar','class' => 'sm:col-span-2']); ?>Todavía no hay años lectivos cargados. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/cropperjs@1.6.2/dist/cropper.min.css">
    <script src="https://cdn.jsdelivr.net/npm/cropperjs@1.6.2/dist/cropper.min.js"></script>
    <script>
        (function () {
            const logoInput = document.getElementById('logo-input');
            const modal = document.getElementById('crop-modal');
            const cropImage = document.getElementById('crop-image');
            const preview = document.getElementById('logo-preview');
            const previewIcon = document.getElementById('logo-preview-icon');
            let cropper = null;

            function abrirModal(dataUrl) {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                cropImage.src = dataUrl;
                if (cropper) cropper.destroy();
                cropper = new Cropper(cropImage, {
                    aspectRatio: 1,
                    viewMode: 1,
                    dragMode: 'move',
                    background: false,
                    autoCropArea: 1,
                });
            }

            function cerrarModal() {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
                if (cropper) { cropper.destroy(); cropper = null; }
            }

            logoInput.addEventListener('change', function () {
                const file = this.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = e => abrirModal(e.target.result);
                reader.readAsDataURL(file);
            });

            document.getElementById('crop-cancel').addEventListener('click', () => { logoInput.value = ''; cerrarModal(); });
            document.getElementById('crop-cancel-2').addEventListener('click', () => { logoInput.value = ''; cerrarModal(); });

            document.getElementById('crop-confirm').addEventListener('click', function () {
                if (!cropper) return;
                cropper.getCroppedCanvas({ width: 500, height: 500, imageSmoothingQuality: 'high' }).toBlob(function (blob) {
                    const recortada = new File([blob], 'logo.png', { type: 'image/png' });
                    const dt = new DataTransfer();
                    dt.items.add(recortada);
                    logoInput.files = dt.files;

                    preview.src = URL.createObjectURL(blob);
                    preview.classList.remove('hidden');
                    if (previewIcon) previewIcon.classList.add('hidden');

                    cerrarModal();
                }, 'image/png');
            });
        })();

        (function () {
            const zona = document.getElementById('zona-arrastrar');
            const input = document.getElementById('imagenes-input');
            const resumen = document.getElementById('imagenes-seleccionadas');
            if (!zona || !input) return;

            function mostrarResumen() {
                const n = input.files.length;
                resumen.textContent = n ? `${n} imagen(es) lista(s) para subir.` : '';
            }

            input.addEventListener('change', mostrarResumen);

            ['dragenter', 'dragover'].forEach(evento => {
                zona.addEventListener(evento, e => {
                    e.preventDefault();
                    zona.classList.add('border-[#0B3D91]', 'bg-[#0B3D91]/5');
                });
            });
            ['dragleave', 'drop'].forEach(evento => {
                zona.addEventListener(evento, e => {
                    e.preventDefault();
                    zona.classList.remove('border-[#0B3D91]', 'bg-[#0B3D91]/5');
                });
            });
            zona.addEventListener('drop', e => {
                if (e.dataTransfer?.files?.length) {
                    input.files = e.dataTransfer.files;
                    mostrarResumen();
                }
            });
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.director', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/director/configuracion/index.blade.php ENDPATH**/ ?>