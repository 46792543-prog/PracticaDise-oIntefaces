

<?php $__env->startSection('titulo', 'Acta de Exámenes'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Acta de Exámenes','subtitulo' => 'Generación automática con alumnos inscriptos en la mesa','eyebrow' => 'Gestión académica','icono' => 'document-check']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Acta de Exámenes','subtitulo' => 'Generación automática con alumnos inscriptos en la mesa','eyebrow' => 'Gestión académica','icono' => 'document-check']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="sg-aviso sg-aviso--info mb-6 sg-revelar">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'sparkles','class' => 'h-5 w-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'sparkles','class' => 'h-5 w-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <span>El acta se <strong>autocompleta</strong> con los alumnos inscriptos en la mesa seleccionada, replicando el formato oficial en papel del instituto.</span>
    </div>

    <div class="sg-card sg-revelar mb-6">
        <div class="sg-card__head">
            <div class="sg-card__titulo">
                <span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <div><h3>Seleccionar mesa</h3><p>Filtrá por carrera y elegí la mesa a completar</p></div>
            </div>
        </div>
        <form method="GET" class="grid sm:grid-cols-3 gap-4 p-6">
            <div>
                <label class="sg-label">CARRERA</label>
                <select name="carrera" onchange="this.form.submit()" class="sg-input w-full">
                    <option value="">Todas</option>
                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($carrera->id_carrera); ?>" <?php if($filtroCarrera == $carrera->id_carrera): echo 'selected'; endif; ?>><?php echo e($carrera->nombre_carrera); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="sm:col-span-2">
                <label class="sg-label">MESA (MATERIA · LLAMADO / FECHA)</label>
                <select name="mesa" onchange="this.form.submit()" class="sg-input w-full">
                    <?php $__empty_1 = true; $__currentLoopData = $mesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($mesa->id_mesa); ?>" <?php if($mesaSeleccionada?->id_mesa === $mesa->id_mesa): echo 'selected'; endif; ?>>
                            <?php echo e($mesa->materia->nombre); ?> — <?php echo e($mesa->llamadoExamen->nombre_llamado); ?> · <?php echo e(\App\Support\FechaEsp::corta($mesa->fecha_examen)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option>No hay mesas cargadas</option>
                    <?php endif; ?>
                </select>
            </div>
        </form>
    </div>

    <?php if($mesaSeleccionada): ?>
        <form method="POST" action="<?php echo e(route('admin.actas.generar', $mesaSeleccionada)); ?>">
            <?php echo csrf_field(); ?>
            <div class="sg-revelar rounded-3xl bg-gradient-to-br from-slate-100 to-blue-50 p-3 sm:p-6 mb-6">
            <div class="relative bg-white rounded-xl shadow-lg ring-1 ring-slate-200 p-6 sm:p-10 max-w-4xl mx-auto overflow-hidden">
                <span class="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-[#0B3D91] via-[#4FC3F7] to-[#FFC107]"></span>
                <div class="flex items-center gap-3 border-b-2 border-[#0B3D91] pb-4 mb-4">
                    <span class="h-11 w-11 rounded-xl bg-gradient-to-br from-[#4FC3F7] to-[#0B3D91] ring-2 ring-[#FFC107] text-white grid place-items-center font-display font-bold text-xs">ISG</span>
                    <div>
                        <p class="font-bold text-slate-800">Instituto Superior San Gregorio</p>
                        <p class="text-xs text-slate-400">San Pedro de Jujuy — Pedro Goyena 33 — Tel. 03888-480686</p>
                    </div>
                </div>

                <div class="flex justify-between items-center mb-4 text-sm">
                    <div class="flex gap-6">
                        <label class="flex items-center gap-2">L: <input type="text" maxlength="20" name="libro" value="<?php echo e(old('libro', $acta->libro ?? '')); ?>" class="w-16 border-0 border-b-2 border-slate-300 text-center rounded-none !shadow-none focus:border-[#0B3D91]"></label>
                        <label class="flex items-center gap-2">F: <input type="text" maxlength="20" name="folio" value="<?php echo e(old('folio', $acta->folio ?? '')); ?>" class="w-16 border-0 border-b-2 border-slate-300 text-center rounded-none !shadow-none focus:border-[#0B3D91]"></label>
                    </div>
                    <div class="flex items-center gap-2">
                        <?php if($acta): ?>
                            <span class="sg-badge <?php echo e($acta->estado === 'generada' ? 'sg-badge--verde' : 'sg-badge--amarillo'); ?>">
                                <?php echo e($acta->estado === 'generada' ? 'Definitiva' : 'Borrador'); ?>

                            </span>
                        <?php endif; ?>
                        <span class="inline-flex items-center gap-1.5 rounded-lg bg-blue-50 text-[#0B3D91] font-semibold px-3 py-1 text-sm"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'calendar','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'calendar','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php echo e(\App\Support\FechaEsp::corta($mesaSeleccionada->fecha_examen)); ?></span>
                    </div>
                </div>

                <h3 class="text-center font-display font-extrabold text-[#0B3D91] tracking-wide mb-5">ACTA DE EXÁMENES <?php echo e(mb_strtoupper($mesaSeleccionada->turnoExamen->nombre_turno)); ?> <?php echo e($mesaSeleccionada->anioLectivo->anio); ?></h3>

                <p class="text-sm mb-1"><strong>Carrera:</strong> <?php echo e($mesaSeleccionada->materia->carrera->nombre_carrera); ?>.</p>
                <p class="text-sm mb-1"><strong>Asignatura:</strong> <?php echo e(mb_strtoupper($mesaSeleccionada->materia->nombre)); ?></p>
                <p class="text-sm mb-4"><strong>Examen de Alumnos:</strong> REGULAR</p>

                <table class="w-full text-xs border-collapse mb-4">
                    <thead>
                        <tr class="bg-[#0B3D91] text-white">
                            <th class="border border-slate-300 px-2 py-1">N°</th>
                            <th class="border border-slate-300 px-2 py-1">Documento</th>
                            <th class="border border-slate-300 px-3 py-1 text-left">Apellido y Nombre</th>
                            <th class="border border-slate-300 px-2 py-1" colspan="3">Calificación</th>
                        </tr>
                        <tr class="bg-blue-50 text-[#0B3D91]">
                            <th class="border border-slate-300"></th>
                            <th class="border border-slate-300"></th>
                            <th class="border border-slate-300"></th>
                            <th class="border border-slate-300 px-2 py-1">Escrito</th>
                            <th class="border border-slate-300 px-2 py-1">Oral</th>
                            <th class="border border-slate-300 px-2 py-1">Final</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $inscripcionesAceptadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $inscripcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $detalle = $acta?->detalles->firstWhere('id_persona_alumno', $inscripcion->id_persona_alumno); ?>
                            <tr>
                                <td class="border border-slate-300 text-center py-1"><?php echo e(str_pad($i + 1, 2, '0', STR_PAD_LEFT)); ?></td>
                                <td class="border border-slate-300 text-center">DNI <?php echo e($inscripcion->personaAlumno->dni); ?></td>
                                <td class="border border-slate-300 px-3"><?php echo e(mb_strtoupper($inscripcion->personaAlumno->apellido)); ?>, <?php echo e(mb_strtoupper($inscripcion->personaAlumno->nombre)); ?></td>
                                <td class="border border-slate-300 p-1">
                                    <input type="text" inputmode="numeric" data-nota name="notas[<?php echo e($inscripcion->id_persona_alumno); ?>][nota_escrito]" value="<?php echo e($detalle->nota_escrito ?? ''); ?>" class="w-full text-center rounded-md py-1 hover:bg-blue-50 focus:bg-blue-50 !shadow-none focus:outline-none">
                                </td>
                                <td class="border border-slate-300 p-1">
                                    <input type="text" inputmode="numeric" data-nota name="notas[<?php echo e($inscripcion->id_persona_alumno); ?>][nota_oral]" value="<?php echo e($detalle->nota_oral ?? ''); ?>" class="w-full text-center rounded-md py-1 hover:bg-blue-50 focus:bg-blue-50 !shadow-none focus:outline-none">
                                </td>
                                <td class="border border-slate-300 p-1">
                                    <input type="text" inputmode="numeric" data-nota name="notas[<?php echo e($inscripcion->id_persona_alumno); ?>][nota_final]" value="<?php echo e($detalle->nota_final ?? ''); ?>" class="w-full text-center font-bold rounded-md py-1 hover:bg-blue-50 focus:bg-blue-50 !shadow-none focus:outline-none">
                                    <select name="notas[<?php echo e($inscripcion->id_persona_alumno); ?>][resultado]" class="w-full text-[10px] border-t border-slate-200 focus:outline-none">
                                        <option value="">—</option>
                                        <option value="aprobado" <?php if(($detalle->resultado ?? null) === 'aprobado'): echo 'selected'; endif; ?>>Aprobado</option>
                                        <option value="desaprobado" <?php if(($detalle->resultado ?? null) === 'desaprobado'): echo 'selected'; endif; ?>>Desaprobado</option>
                                        <option value="ausente" <?php if(($detalle->resultado ?? null) === 'ausente'): echo 'selected'; endif; ?>>Ausente</option>
                                    </select>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6" class="border border-slate-300 text-center py-4 text-slate-400">Nadie se inscribió a esta mesa todavía.</td></tr>
                        <?php endif; ?>
                        <?php for($i = $inscripcionesAceptadas->count(); $i < max(7, $inscripcionesAceptadas->count()); $i++): ?>
                            <tr class="text-slate-300">
                                <td class="border border-slate-300 text-center py-1"><?php echo e(str_pad($i + 1, 2, '0', STR_PAD_LEFT)); ?></td>
                                <td class="border border-slate-300"></td><td class="border border-slate-300"></td>
                                <td class="border border-slate-300"></td><td class="border border-slate-300"></td><td class="border border-slate-300"></td>
                            </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>

                <label class="sg-label">OBSERVACIONES:</label>
                <textarea name="observaciones" rows="2" maxlength="2000" class="w-full rounded-xl border-[1.5px] border-slate-200 bg-slate-50 p-3 text-sm mb-6"><?php echo e($acta->observaciones ?? ''); ?></textarea>

                <div class="flex flex-wrap justify-end gap-x-8 gap-y-2 text-sm mb-10 rounded-xl bg-slate-50 px-5 py-3">
                    <p>TOTAL DE ALUMNOS: <strong><?php echo e($inscripcionesAceptadas->count()); ?></strong></p>
                    <p>APROBADOS: <strong><?php echo e($acta?->detalles->where('resultado', 'aprobado')->count() ?: '—'); ?></strong></p>
                    <p>DESAPROBADOS: <strong><?php echo e($acta?->detalles->where('resultado', 'desaprobado')->count() ?: '—'); ?></strong></p>
                    <p>AUSENTES: <strong><?php echo e($acta?->detalles->where('resultado', 'ausente')->count() ?: '—'); ?></strong></p>
                </div>

                <div class="grid grid-cols-3 gap-6 text-center text-sm">
                    <p class="border-t border-slate-400 pt-2">Presidente</p>
                    <p class="border-t border-slate-400 pt-2">Vocal 1</p>
                    <p class="border-t border-slate-400 pt-2">Vocal 2</p>
                </div>
                <p class="text-center text-xs font-semibold mt-6">
                    SAN PEDRO DE JUJUY, <?php echo e(mb_strtoupper(\Illuminate\Support\Str::after(\App\Support\FechaEsp::larga($mesaSeleccionada->fecha_examen), ', '))); ?>

                </p>
            </div>
            </div>

            <div class="sticky bottom-4 flex flex-wrap justify-end gap-3 rounded-2xl bg-white/90 backdrop-blur border border-slate-200 p-3 shadow-lg">
                <a href="<?php echo e(route('admin.mesas.index')); ?>" class="sg-btn sg-btn--borde"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'clock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'clock']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Historial de actas</a>
                <?php if($acta): ?>
                    <a href="<?php echo e(route('admin.mesas.acta', $mesaSeleccionada)); ?>" target="_blank" class="sg-btn sg-btn--borde"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'download']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'download']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Ver / descargar PDF</a>
                <?php endif; ?>
                <button type="submit" formaction="<?php echo e(route('admin.actas.guardar', $mesaSeleccionada)); ?>" class="sg-btn sg-btn--suave"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'pencil']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'pencil']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Guardar borrador</button>
                <button type="submit" formtarget="_blank" class="sg-btn sg-btn--primario"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'printer']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'printer']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Generar e imprimir acta</button>
            </div>
        </form>
    <?php else: ?>
        <div class="sg-card sg-revelar"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'document','titulo' => 'Sin mesas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'document','titulo' => 'Sin mesas']); ?>No hay mesas de examen cargadas todavía. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/admin/actas/index.blade.php ENDPATH**/ ?>