

<?php $__env->startSection('titulo', 'Mesas de examen'); ?>
<?php $__env->startSection('subtitulo', \App\Support\FechaEsp::larga(now())); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Mesas de examen','subtitulo' => \App\Support\FechaEsp::larga(now()),'eyebrow' => 'Gestión académica','icono' => 'clipboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Mesas de examen','subtitulo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\App\Support\FechaEsp::larga(now())),'eyebrow' => 'Gestión académica','icono' => 'clipboard']); ?>
        <a href="<?php echo e(route('admin.mesas.create')); ?>" class="sg-btn sg-btn--primario">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Nueva mesa de examen
        </a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <form method="GET" class="sg-card sg-revelar p-4 mb-6 flex flex-wrap items-end gap-4">
        <div class="flex-1 min-w-[220px]">
            <label class="sg-label">Buscar</label>
            <div class="sg-campo-icono">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <input type="text" name="q" value="<?php echo e($busqueda); ?>" placeholder="Buscar por materia..." maxlength="50" class="sg-input w-full">
            </div>
        </div>
        <div class="w-full sm:w-64">
            <label class="sg-label">Turno</label>
            <select name="turno" onchange="this.form.submit()" class="sg-input">
                <?php $__currentLoopData = $turnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($t->id_turno); ?>" <?php if($turno == $t->id_turno): echo 'selected'; endif; ?>><?php echo e($t->nombre_turno); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </form>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.tarjeta','data' => ['cuerpo' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.tarjeta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['cuerpo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
        <table class="sg-tabla">
            <thead>
                <tr>
                    <th>Materia</th>
                    <th>Fecha examen</th>
                    <th>Inscripción</th>
                    <th>Llamado</th>
                    <th>Tribunal</th>
                    <th>Estado</th>
                    <th class="text-right">Acciones</th>
                </tr>
            </thead>
            <tbody class="sg-filas">
                <?php $__empty_1 = true; $__currentLoopData = $mesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $presidente = $mesa->tribunal->first(fn ($t) => $t->rolTribunal->nombre_rol === 'Presidente');
                        $estadoMesa = $mesa->estadoMesa->nombre_estado;
                    ?>
                    <tr>
                        <td>
                            <div class="flex items-center gap-3">
                                <span class="flex h-11 w-11 shrink-0 flex-col items-center justify-center rounded-xl bg-blue-50 text-[#0B3D91] leading-none">
                                    <span class="font-display text-sm font-extrabold"><?php echo e($mesa->fecha_examen?->format('d')); ?></span>
                                    <span class="text-[9px] font-bold uppercase"><?php echo e($mesa->fecha_examen ? \App\Support\FechaEsp::mesAbrev($mesa->fecha_examen) : ''); ?></span>
                                </span>
                                <div class="min-w-0">
                                    <p class="font-semibold text-slate-800"><?php echo e($mesa->materia->nombre); ?></p>
                                    <p class="text-xs text-slate-400"><?php echo e($mesa->materia->carrera->nombre_carrera); ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="whitespace-nowrap"><?php echo e(\App\Support\FechaEsp::corta($mesa->fecha_examen)); ?></td>
                        <td class="text-xs whitespace-nowrap">
                            <?php echo e(\App\Support\FechaEsp::corta($mesa->fecha_inicio_inscripcion)); ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'arrow-right','class' => 'inline h-3 w-3 text-slate-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'arrow-right','class' => 'inline h-3 w-3 text-slate-300']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php echo e(\App\Support\FechaEsp::corta($mesa->fecha_fin_inscripcion)); ?>

                        </td>
                        <td><span class="sg-badge sg-badge--celeste sg-badge--sin-punto"><?php echo e($mesa->llamadoExamen->nombre_llamado); ?></span></td>
                        <td>
                            <?php if($presidente): ?>
                                <span class="inline-flex items-center gap-2">
                                    <span class="sg-avatar !h-7 !w-7 !rounded-lg !text-[10px]"><?php echo e(mb_substr($presidente->profesor->nombre, 0, 1)); ?><?php echo e(mb_substr($presidente->profesor->apellido, 0, 1)); ?></span>
                                    <span class="text-sm"><?php echo e($presidente->profesor->apellido . ', ' . mb_substr($presidente->profesor->nombre, 0, 1) . '. (Pres.)'); ?></span>
                                </span>
                            <?php else: ?>
                                <span class="text-slate-400 italic">Sin asignar</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                    'sg-badge',
                                    'sg-badge--verde' => $estadoMesa === 'Finalizada',
                                    'sg-badge--azul' => $estadoMesa === 'Programada',
                                    'sg-badge--rojo' => $estadoMesa === 'Cancelada',
                                ]) ?>">
                                <?php echo e($estadoMesa); ?>

                            </span>
                        </td>
                        <td>
                            <div class="flex items-center justify-end gap-1.5">
                                <a href="<?php echo e(route('admin.mesas.acta', $mesa)); ?>" class="sg-btn sg-btn--suave sg-btn--chico">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'document']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'document']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Acta
                                    <?php if($mesa->acta): ?>
                                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sg-badge sg-badge--sin-punto !py-0.5 !ml-1', 'sg-badge--amarillo' => $mesa->acta->estado === 'borrador', 'sg-badge--verde' => $mesa->acta->estado === 'generada']) ?>">
                                            <?php echo e($mesa->acta->estado === 'borrador' ? 'Borrador' : 'Generada'); ?>

                                        </span>
                                    <?php endif; ?>
                                </a>
                                <?php if($mesa->acta && $mesa->acta->estado === 'borrador'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.actas.generar', $mesa)); ?>" onsubmit="return confirm('¿Cerrar el acta de <?php echo e($mesa->materia->nombre); ?>? Una vez generada no se puede volver a editar desde acá.');">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="libro" value="<?php echo e($mesa->acta->libro); ?>">
                                        <input type="hidden" name="folio" value="<?php echo e($mesa->acta->folio); ?>">
                                        <input type="hidden" name="observaciones" value="<?php echo e($mesa->acta->observaciones); ?>">
                                        <?php $__currentLoopData = $mesa->acta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="notas[<?php echo e($detalle->id_persona_alumno); ?>][nota_escrito]" value="<?php echo e($detalle->nota_escrito); ?>">
                                            <input type="hidden" name="notas[<?php echo e($detalle->id_persona_alumno); ?>][nota_oral]" value="<?php echo e($detalle->nota_oral); ?>">
                                            <input type="hidden" name="notas[<?php echo e($detalle->id_persona_alumno); ?>][nota_final]" value="<?php echo e($detalle->nota_final); ?>">
                                            <input type="hidden" name="notas[<?php echo e($detalle->id_persona_alumno); ?>][resultado]" value="<?php echo e($detalle->resultado); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="submit" class="sg-btn sg-btn--verde sg-btn--icono" title="Cerrar acta"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'lock','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'lock','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                    </form>
                                <?php endif; ?>
                                <?php if($estadoMesa === 'Programada'): ?>
                                    <a href="<?php echo e(route('admin.mesas.edit', $mesa)); ?>" class="sg-btn sg-btn--borde sg-btn--icono" title="Editar"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'pencil','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'pencil','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></a>
                                    <form method="POST" action="<?php echo e(route('admin.mesas.destroy', $mesa)); ?>" onsubmit="return confirm('¿Cancelar esta mesa?');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="sg-btn sg-btn--peligro sg-btn--icono" title="Cancelar mesa"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'x','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'x','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'clipboard','titulo' => 'Sin mesas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'clipboard','titulo' => 'Sin mesas']); ?>No hay mesas programadas para este turno. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if($mesas->hasPages()): ?>
             <?php $__env->slot('pie', null, []); ?> <?php echo e($mesas->links()); ?> <?php $__env->endSlot(); ?>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/admin/mesas/index.blade.php ENDPATH**/ ?>