

<?php $__env->startSection('titulo', 'Asignación de Materias y Horarios'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Profesores y horarios','subtitulo' => 'Carga y consulta de materias asignadas a cada docente — Año lectivo '.e($anioLectivo?->anio).'','eyebrow' => 'Plantel docente','icono' => 'briefcase']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Profesores y horarios','subtitulo' => 'Carga y consulta de materias asignadas a cada docente — Año lectivo '.e($anioLectivo?->anio).'','eyebrow' => 'Plantel docente','icono' => 'briefcase']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="sg-card sg-revelar mb-8 overflow-hidden">
    <div class="relative bg-gradient-to-r from-[#082A66] via-[#0B3D91] to-[#1565C0] px-6 py-4 overflow-hidden">
        <span class="absolute -right-8 -top-10 h-28 w-28 rounded-full border-[10px] border-[#FFC107]/25"></span>
        <h2 class="relative text-white font-display font-bold flex items-center gap-3"><span class="grid h-9 w-9 place-items-center rounded-xl bg-white/15 text-[#FFD54F]"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'calendar','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'calendar','class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span> Asignar materia y horario a profesor</h2>
    </div>
    <div class="p-6">
        <form id="form-asignacion" method="POST" action="<?php echo e(route('admin.profesores.asignaciones.store')); ?>" class="grid sm:grid-cols-2 gap-4 mb-4">
            <?php echo csrf_field(); ?>
            <div>
                <label class="sg-label">PROFESOR *</label>
                <select name="id_profesor" id="input-id-profesor" required class="sg-input w-full">
                    <option value="">Seleccioná profesor...</option>
                    <?php $__currentLoopData = $profesoresActivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($profesor->id_profesor); ?>"><?php echo e($profesor->apellido); ?>, <?php echo e($profesor->nombre); ?> — <?php echo e($profesor->especialidad->nombre_especialidad); ?> (<?php echo e($profesor->condicion); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="sg-label">MATERIA *</label>
                <select name="id_materia" id="input-id-materia" required class="sg-input w-full">
                    <option value="">Ej: Organización y Gestión en Enfermería</option>
                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <optgroup label="<?php echo e($carrera->nombre_carrera); ?>">
                            <?php $__currentLoopData = $carrera->materias()->with('nombreMateria', 'anioCursada')->orderBy('numero_orden')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($materia->id_materia); ?>"><?php echo e($materia->nombre); ?> (<?php echo e($materia->anioCursada->nombre_anio); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </optgroup>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>            </div>
            <div>
                <label class="sg-label">AÑO LECTIVO *</label>
                <select name="id_anio_lectivo" id="input-id-anio-lectivo" required class="sg-input w-full">
                    <?php $__currentLoopData = $aniosLectivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($anio->id_anio_lectivo); ?>" <?php if($anio->id_anio_lectivo == $anioLectivo?->id_anio_lectivo): echo 'selected'; endif; ?>><?php echo e($anio->anio); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="sg-label">HORA INICIO *</label>
                    <input type="time" name="hora_inicio" id="input-hora-inicio" required class="sg-input w-full">
                </div>
                <div>
                    <label class="sg-label">HORA FIN *</label>
                    <input type="time" name="hora_fin" id="input-hora-fin" required class="sg-input w-full">
                </div>
            </div>
            <div>
                <label class="sg-label">AULA</label>
                <input type="text" maxlength="20" name="aula" id="input-aula" placeholder="Ej: Aula 3" class="sg-input w-full">
            </div>
            <div class="sm:col-span-2">
                <label class="sg-label">DÍAS DE CURSADA *</label>
                <div class="flex flex-wrap gap-2">
                    <?php $__currentLoopData = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center gap-2 text-sm font-medium text-slate-600 bg-white border-[1.5px] border-slate-200 rounded-xl px-4 py-2 cursor-pointer transition-colors hover:border-[#4FC3F7] has-[:checked]:bg-[#0B3D91] has-[:checked]:border-[#0B3D91] has-[:checked]:text-white">
                            <input type="checkbox" name="dias[]" value="<?php echo e($dia); ?>" class="dia-checkbox h-3.5 w-3.5"> <?php echo e($dia); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p class="text-xs text-slate-400 mt-1.5">La hora de arriba se aplica a todos los días que tildes acá. Si el mismo profesor da la misma materia otro día con otro horario, guardá esto primero y después volvé a cargar ese otro día con su hora — no se pisan entre sí.</p>
            </div>
            <div class="sm:col-span-2 flex justify-end gap-3 pt-4 border-t border-slate-100">
                <span id="editando-aviso" class="hidden sg-badge sg-badge--amarillo self-center mr-auto">Editando un día de una asignación existente — al guardar se actualiza solo ese día, los demás no se tocan.</span>
                <button type="reset" onclick="cancelarEdicionAsignacion()" class="sg-btn sg-btn--borde">Limpiar</button>
                <button type="submit" class="sg-btn sg-btn--primario"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'check']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'check']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Guardar asignación</button>
            </div>
        </form>

        <details id="detalle-padron" class="text-sm mt-6 rounded-2xl border-[1.5px] border-dashed border-slate-200 bg-slate-50/60 open:bg-white open:border-[#BDE5FA] transition-colors">
            <summary class="cursor-pointer list-none flex items-center gap-3 px-4 py-3 text-[#0B3D91] font-semibold"><span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'user-plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'user-plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span> Agregar nuevo profesor al padrón <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'chevron-down','class' => 'h-4 w-4 ml-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'chevron-down','class' => 'h-4 w-4 ml-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></summary>
            <div class="px-4 pb-4">
            <form id="form-profesor" method="POST" action="<?php echo e(route('admin.profesores.store')); ?>" class="grid sm:grid-cols-3 gap-3 mt-3">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" id="input-profesor-method" value="">
                <input type="text" inputmode="numeric" data-solo="numeros" data-max-len="8" maxlength="8" name="dni" id="input-profesor-dni" placeholder="DNI" required class="sg-input">
                <input type="text" data-solo="letras" data-max-len="25" maxlength="25" name="apellido" id="input-profesor-apellido" placeholder="Apellido" required class="sg-input">
                <input type="text" data-solo="letras" data-max-len="25" maxlength="25" name="nombre" id="input-profesor-nombre" placeholder="Nombre" required class="sg-input">
                <input type="email" maxlength="25" name="email" id="input-profesor-email" placeholder="Email (opcional)" class="sg-input">
                <div class="flex gap-2 min-w-0">
                    <select name="id_especialidad" id="input-profesor-especialidad" required class="sg-input min-w-0 flex-1">
                        <option value="">Especialidad...</option>
                        <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($especialidad->id_especialidad); ?>"><?php echo e($especialidad->nombre_especialidad); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button type="button" onclick="abrirModalEspecialidad()" title="Agregar nueva especialidad"
                            class="shrink-0 w-[46px] flex items-center justify-center rounded-xl bg-blue-100 text-[#0B3D91] hover:bg-[#0B3D91] hover:text-white transition-colors"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                </div>
                <select name="condicion" id="input-profesor-condicion" required class="sg-input">
                    <option value="">Condición...</option>
                    <option value="Titular">Titular</option>
                    <option value="Suplente">Suplente</option>
                </select>
                <div class="sm:col-span-3 flex justify-end items-center gap-3">
                    <span id="editando-profesor-aviso" class="hidden sg-badge sg-badge--amarillo mr-auto">Editando un profesor existente — al guardar se actualizará.</span>
                    <button type="button" onclick="cancelarEdicionProfesor()" class="sg-btn sg-btn--borde">Limpiar</button>
                    <button type="submit" id="input-profesor-submit" class="sg-btn sg-btn--azul">Guardar docente</button>
                </div>
            </form>
            </div>
        </details>
    </div>
    </div>

    <div class="sg-seccion-titulo sg-revelar">
        <span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'users']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
        <h2>Profesores registrados</h2>
    </div>
    <div class="sg-card sg-revelar mb-8 overflow-hidden">
        <div class="overflow-x-auto">
        <table class="sg-tabla">
            <thead>
                <tr>
                    <th>Profesor</th>
                    <th>Especialidad</th>
                    <th>Condición</th>
                    <th>Estado</th>
                    <th class="text-right">Acciones</th>
                </tr>
            </thead>
            <tbody class="sg-filas">
                <?php $__empty_1 = true; $__currentLoopData = $profesoresPaginados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $edicionProfesorPayload = [
                            'id_profesor' => $profesor->id_profesor,
                            'dni' => $profesor->dni,
                            'apellido' => $profesor->apellido,
                            'nombre' => $profesor->nombre,
                            'email' => $profesor->email,
                            'id_especialidad' => $profesor->id_especialidad,
                            'condicion' => $profesor->condicion,
                        ];
                    ?>
                    <tr class="<?php echo e($profesor->activo ? '' : 'opacity-60'); ?>">
                        <td>
                            <div class="flex items-center gap-3 min-w-0">
                                <span class="sg-avatar"><?php echo e(mb_substr($profesor->nombre, 0, 1)); ?><?php echo e(mb_substr($profesor->apellido, 0, 1)); ?></span>
                                <div class="min-w-0">
                                    <p class="font-semibold text-slate-800"><?php echo e($profesor->apellido); ?>, <?php echo e($profesor->nombre); ?></p>
                                    <p class="text-xs text-slate-400 truncate max-w-[260px]">DNI <?php echo e($profesor->dni); ?><?php if($profesor->email): ?> · <?php echo e($profesor->email); ?><?php endif; ?></p>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="inline-flex items-center gap-1.5 text-sm text-slate-600">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'academic','class' => 'h-4 w-4 shrink-0 text-[#4FC3F7]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'academic','class' => 'h-4 w-4 shrink-0 text-[#4FC3F7]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <span class="leading-tight"><?php echo e($profesor->especialidad->nombre_especialidad); ?></span>
                            </span>
                        </td>
                        <td>
                            <span class="sg-badge sg-badge--sin-punto <?php echo e($profesor->condicion === 'Titular' ? 'sg-badge--azul' : 'sg-badge--amarillo'); ?>"><?php echo e($profesor->condicion); ?></span>
                        </td>
                        <td>
                            <span class="sg-badge <?php echo e($profesor->activo ? 'sg-badge--verde' : 'sg-badge--rojo'); ?>">
                                <?php echo e($profesor->activo ? 'Activo' : 'Dado de baja'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="flex items-center justify-end gap-1.5">
                                <button type="button" class="sg-btn sg-btn--suave sg-btn--icono" title="Editar profesor" aria-label="Editar profesor"
                                        onclick='editarProfesor(<?php echo json_encode($edicionProfesorPayload, 15, 512) ?>)'><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'pencil','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'pencil','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                <?php if($profesor->activo): ?>
                                    <form method="POST" action="<?php echo e(route('admin.profesores.baja', $profesor)); ?>" data-confirm="¿Dar de baja a este profesor? Ya no va a poder asignarse a nuevas materias ni tribunales.">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <button class="sg-btn sg-btn--peligro sg-btn--icono" title="Dar de baja" aria-label="Dar de baja"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'user-minus','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'user-minus','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" action="<?php echo e(route('admin.profesores.reactivar', $profesor)); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <button class="sg-btn sg-btn--verde sg-btn--icono" title="Reactivar" aria-label="Reactivar"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'refresh','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'refresh','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'briefcase']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'briefcase']); ?>No hay profesores cargados. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
        <?php if($profesoresPaginados->hasPages()): ?>
            <div class="sg-card__foot"><?php echo e($profesoresPaginados->links()); ?></div>
        <?php endif; ?>
    </div>

    
    <div id="modal-especialidad" class="hidden fixed inset-0 bg-[#04153A]/50 backdrop-blur-sm z-[70] items-center justify-center p-4">
        <div class="sg-modal bg-white rounded-3xl shadow-2xl ring-1 ring-slate-200/60 w-full max-w-sm p-6 max-h-[85vh] overflow-y-auto">
            <div class="flex items-start justify-between mb-4">
                <h3 class="font-display font-bold text-slate-800 flex items-center gap-3"><span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span> Especialidades</h3>
                <button type="button" onclick="cerrarModalEspecialidad()" class="grid h-9 w-9 place-items-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors" aria-label="Cerrar"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'x']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
            </div>
            <p class="text-xs text-slate-400 -mt-2 mb-4">Áreas de formación del profesor (ej. Enfermería Pediátrica, Farmacología) — no es el nombre de una materia puntual, eso se elige al armar la asignación.</p>

            <p id="especialidad-error" class="hidden text-xs text-red-500 mb-3"></p>

            <div id="lista-especialidades" class="space-y-2 mb-5">
                <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex gap-2 items-center border border-slate-200 rounded-xl p-2 hover:border-blue-200 transition-colors" data-id="<?php echo e($especialidad->id_especialidad); ?>">
                        <form method="POST" action="<?php echo e(route('admin.profesores.especialidades.update', $especialidad)); ?>" class="form-especialidad-update flex flex-1 gap-2 items-center min-w-0">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <input type="text" name="nombre_especialidad" value="<?php echo e($especialidad->nombre_especialidad); ?>" required maxlength="45"
                                   class="sg-input sg-input--chico min-w-0 flex-1">
                            <button type="submit" title="Guardar cambios" class="sg-btn sg-btn--suave sg-btn--chico shrink-0">Guardar</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.profesores.especialidades.destroy', $especialidad)); ?>" class="form-especialidad-destroy" data-confirm-especialidad="<?php echo e($especialidad->nombre_especialidad); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" title="Eliminar especialidad" class="sg-btn sg-btn--peligro sg-btn--icono shrink-0"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'trash','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'trash','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <p class="sg-label mb-2">Agregar nueva especialidad</p>
            <form id="form-especialidad-nueva" method="POST" action="<?php echo e(route('admin.profesores.especialidades.store')); ?>" class="flex gap-2">
                <?php echo csrf_field(); ?>
                <input type="text" name="nombre_especialidad" required autofocus maxlength="45" placeholder="Ej: Enfermería Pediátrica"
                       class="sg-input sg-input--chico min-w-0 flex-1">
                <button type="submit" class="sg-btn sg-btn--azul sg-btn--chico shrink-0">Agregar</button>
            </form>
        </div>
    </div>

    <script>
        function abrirModalEspecialidad() {
            const modal = document.getElementById('modal-especialidad');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        function cerrarModalEspecialidad() {
            const modal = document.getElementById('modal-especialidad');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }

        // Las 3 acciones del modal de especialidades (agregar, guardar, eliminar) se
        // mandan por fetch en vez de un submit normal, para que el modal no se
        // cierre ni la página recargue al usarlas.
        (function () {
            const csrfToken = <?php echo json_encode(csrf_token(), 15, 512) ?>;
            const lista = document.getElementById('lista-especialidades');
            const errorBox = document.getElementById('especialidad-error');
            const selectEspecialidad = document.getElementById('input-profesor-especialidad');

            function mostrarError(mensaje) {
                errorBox.textContent = mensaje;
                errorBox.classList.remove('hidden');
            }

            function ocultarError() {
                errorBox.classList.add('hidden');
                errorBox.textContent = '';
            }

            function escaparHtml(texto) {
                const div = document.createElement('div');
                div.textContent = texto;
                return div.innerHTML;
            }

            function filaEspecialidad(id, nombre) {
                const nombreSeguro = escaparHtml(nombre);
                const div = document.createElement('div');
                div.className = 'flex gap-2 items-center border border-slate-200 rounded-xl p-2 hover:border-blue-200 transition-colors';
                div.dataset.id = id;
                div.innerHTML = `
                    <form method="POST" action="/admin/profesores/especialidades/${id}" class="form-especialidad-update flex flex-1 gap-2 items-center min-w-0">
                        <input type="hidden" name="_token" value="${csrfToken}">
                        <input type="hidden" name="_method" value="PUT">
                        <input type="text" name="nombre_especialidad" value="${nombreSeguro}" required maxlength="45" class="sg-input sg-input--chico min-w-0 flex-1">
                        <button type="submit" title="Guardar cambios" class="sg-btn sg-btn--suave sg-btn--chico shrink-0">Guardar</button>
                    </form>
                    <form method="POST" action="/admin/profesores/especialidades/${id}" class="form-especialidad-destroy" data-confirm-especialidad="${nombreSeguro}">
                        <input type="hidden" name="_token" value="${csrfToken}">
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" title="Eliminar especialidad" class="sg-btn sg-btn--peligro sg-btn--icono shrink-0">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="!h-4 !w-4"><path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" /></svg>
                        </button>
                    </form>
                `;

                return div;
            }

            function agregarOptionSelect(id, nombre) {
                const option = document.createElement('option');
                option.value = id;
                option.textContent = nombre;
                selectEspecialidad.appendChild(option);
            }

            lista.addEventListener('submit', function (evento) {
                const form = evento.target;

                if (form.classList.contains('form-especialidad-update')) {
                    evento.preventDefault();
                    ocultarError();

                    const input = form.querySelector('[name="nombre_especialidad"]');

                    fetch(form.action, {
                        method: 'POST',
                        headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': csrfToken },
                        body: new FormData(form),
                    })
                        .then(async (res) => {
                            const datos = await res.json();
                            if (! res.ok) throw datos;

                            const option = selectEspecialidad.querySelector(`option[value="${datos.especialidad.id_especialidad}"]`);
                            if (option) option.textContent = datos.especialidad.nombre_especialidad;

                            input.classList.add('ring-2', 'ring-emerald-300');
                            setTimeout(() => input.classList.remove('ring-2', 'ring-emerald-300'), 1200);
                        })
                        .catch((datos) => mostrarError(datos.message || Object.values(datos.errors ?? {}).flat().join(' ') || 'No se pudo guardar la especialidad.'));

                    return;
                }

                if (form.classList.contains('form-especialidad-destroy')) {
                    evento.preventDefault();

                    if (! confirm(`¿Eliminar la especialidad '${form.dataset.confirmEspecialidad}'?`)) return;

                    ocultarError();
                    const fila = form.closest('[data-id]');
                    const id = fila.dataset.id;

                    fetch(form.action, {
                        method: 'POST',
                        headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': csrfToken },
                        body: new FormData(form),
                    })
                        .then(async (res) => {
                            const datos = await res.json();
                            if (! res.ok) throw datos;

                            fila.remove();
                            const option = selectEspecialidad.querySelector(`option[value="${id}"]`);
                            if (option) option.remove();
                        })
                        .catch((datos) => mostrarError(datos.message || 'No se pudo eliminar la especialidad.'));
                }
            });

            document.getElementById('form-especialidad-nueva').addEventListener('submit', function (evento) {
                evento.preventDefault();
                ocultarError();

                const form = evento.target;
                const input = form.querySelector('[name="nombre_especialidad"]');

                fetch(form.action, {
                    method: 'POST',
                    headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': csrfToken },
                    body: new FormData(form),
                })
                    .then(async (res) => {
                        const datos = await res.json();
                        if (! res.ok) throw datos;

                        lista.appendChild(filaEspecialidad(datos.especialidad.id_especialidad, datos.especialidad.nombre_especialidad));
                        agregarOptionSelect(datos.especialidad.id_especialidad, datos.especialidad.nombre_especialidad);
                        input.value = '';
                        input.focus();
                    })
                    .catch((datos) => mostrarError(datos.message || Object.values(datos.errors ?? {}).flat().join(' ') || 'No se pudo agregar la especialidad.'));
            });
        })();

        function editarAsignacion(asignacion) {
            document.getElementById('input-id-profesor').value = asignacion.id_profesor;
            document.getElementById('input-id-materia').value = asignacion.id_materia;
            document.getElementById('input-id-anio-lectivo').value = asignacion.id_anio_lectivo;
            document.getElementById('input-aula').value = asignacion.aula ?? '';
            document.getElementById('input-hora-inicio').value = asignacion.hora_inicio ?? '';
            document.getElementById('input-hora-fin').value = asignacion.hora_fin ?? '';

            document.querySelectorAll('.dia-checkbox').forEach(function (checkbox) {
                checkbox.checked = asignacion.dias.includes(checkbox.value);
            });

            actualizarMateriasDisponibles();
            document.getElementById('editando-aviso').classList.remove('hidden');
            document.getElementById('form-asignacion').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        function cancelarEdicionAsignacion() {
            document.getElementById('editando-aviso').classList.add('hidden');
            // El reset del form se aplica después del click: recalculamos cuando ya terminó.
            setTimeout(actualizarMateriasDisponibles);
        }

        // Una materia ya asignada a otro profesor en el año lectivo elegido no se ofrece en el combo.
        const materiasOcupadas = <?php echo json_encode($materiasOcupadas, 15, 512) ?>;

        function materiaTomadaPorOtro(idMateria) {
            const idProfesor = document.getElementById('input-id-profesor').value;
            const idAnio = document.getElementById('input-id-anio-lectivo').value;

            return materiasOcupadas.some(function (o) {
                return String(o.id_materia) === String(idMateria)
                    && String(o.id_anio_lectivo) === String(idAnio)
                    && String(o.id_profesor) !== String(idProfesor);
            });
        }

        function actualizarMateriasDisponibles() {
            const selectMateria = document.getElementById('input-id-materia');

            selectMateria.querySelectorAll('option[value]:not([value=""])').forEach(function (opcion) {
                const ocultar = materiaTomadaPorOtro(opcion.value);
                opcion.hidden = ocultar;
                opcion.disabled = ocultar;
            });

            selectMateria.querySelectorAll('optgroup').forEach(function (grupo) {
                grupo.hidden = !grupo.querySelector('option:not([hidden])');
            });

            if (selectMateria.selectedOptions[0]?.hidden) {
                selectMateria.value = '';
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            ['input-id-profesor', 'input-id-anio-lectivo'].forEach(function (id) {
                document.getElementById(id).addEventListener('change', actualizarMateriasDisponibles);
            });
            actualizarMateriasDisponibles();
        });

        const rutaBaseProfesores = <?php echo json_encode(url('/admin/profesores'), 15, 512) ?>;
        const rutaGuardarProfesor = <?php echo json_encode(route('admin.profesores.store'), 15, 512) ?>;

        function editarProfesor(profesor) {
            document.getElementById('form-profesor').action = rutaBaseProfesores + '/' + profesor.id_profesor;
            document.getElementById('input-profesor-method').value = 'PUT';
            document.getElementById('input-profesor-dni').value = profesor.dni;
            document.getElementById('input-profesor-apellido').value = profesor.apellido;
            document.getElementById('input-profesor-nombre').value = profesor.nombre;
            document.getElementById('input-profesor-email').value = profesor.email ?? '';
            document.getElementById('input-profesor-especialidad').value = profesor.id_especialidad;
            document.getElementById('input-profesor-condicion').value = profesor.condicion;
            document.getElementById('input-profesor-submit').textContent = 'Guardar cambios';
            document.getElementById('editando-profesor-aviso').classList.remove('hidden');
            document.getElementById('detalle-padron').open = true;
            document.getElementById('detalle-padron').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        function cancelarEdicionProfesor() {
            document.getElementById('form-profesor').reset();
            document.getElementById('form-profesor').action = rutaGuardarProfesor;
            document.getElementById('input-profesor-method').value = '';
            document.getElementById('input-profesor-submit').textContent = 'Guardar docente';
            document.getElementById('editando-profesor-aviso').classList.add('hidden');
        }
    </script>

    <div class="sg-seccion-titulo sg-revelar">
        <span class="sg-chip sg-chip--chico sg-chip--amarillo"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'clock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'clock']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
        <h2>Asignaciones ya cargadas</h2>
    </div>
    <div class="sg-card sg-revelar overflow-hidden">
        <div class="flex flex-wrap gap-2 p-4 pb-0">
            <a href="<?php echo e(route('admin.profesores.index', array_filter(['materia' => $filtros['materia'] ?? null]))); ?>"
               class="sg-btn sg-btn--chico <?php echo e($sinAsignar ? 'sg-btn--borde' : 'sg-btn--azul'); ?>">Asignaciones cargadas</a>
            <a href="<?php echo e(route('admin.profesores.index', array_filter(['materia' => $filtros['materia'] ?? null, 'sin_asignar' => 1]))); ?>"
               class="sg-btn sg-btn--chico <?php echo e($sinAsignar ? 'sg-btn--azul' : 'sg-btn--borde'); ?>">Materias sin profesor asignado
               <?php if($materiasSinAsignar->total() > 0): ?><span class="sg-badge sg-badge--sin-punto sg-badge--rojo ml-1"><?php echo e($materiasSinAsignar->total()); ?></span><?php endif; ?></a>
        </div>

        <form method="GET" class="flex flex-wrap gap-3 p-4 border-b border-slate-100 bg-slate-50/60">
            <?php if($sinAsignar): ?>
                <input type="hidden" name="sin_asignar" value="1">
            <?php else: ?>
                <select name="profesor" onchange="this.form.submit()" class="sg-input w-auto">
                    <option value="">Todos los profesores</option>
                    <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($profesor->id_profesor); ?>" <?php if(($filtros['profesor'] ?? null) == $profesor->id_profesor): echo 'selected'; endif; ?>><?php echo e($profesor->apellido); ?>, <?php echo e($profesor->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="dia" onchange="this.form.submit()" class="sg-input w-auto">
                    <option value="">Todos los días</option>
                    <?php $__currentLoopData = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dia); ?>" <?php if(($filtros['dia'] ?? null) === $dia): echo 'selected'; endif; ?>><?php echo e($dia); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endif; ?>
            <input type="text" name="materia" value="<?php echo e($filtros['materia'] ?? ''); ?>" placeholder="Buscar materia..." maxlength="50" class="sg-input w-auto flex-1 min-w-[180px]">
            <button class="sg-btn sg-btn--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Buscar</button>
        </form>

        <?php if($sinAsignar): ?>
        <div class="overflow-x-auto">
        <table class="sg-tabla">
            <thead>
                <tr>
                    <th>Materia</th>
                    <th>Carrera</th>
                    <th>Año</th>
                    <th></th>
                </tr>
            </thead>
            <tbody class="sg-filas">
                <?php $__empty_1 = true; $__currentLoopData = $materiasSinAsignar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-slate-700"><?php echo e($materia->nombre); ?></td>
                        <td class="text-xs text-blue-600"><?php echo e($materia->carrera->nombre_carrera); ?></td>
                        <td class="text-slate-500"><?php echo e($materia->anioCursada->nombre_anio); ?></td>
                        <td class="text-right">
                            <button type="button" class="sg-btn sg-btn--suave sg-btn--chico" onclick="preseleccionarMateria(<?php echo e($materia->id_materia); ?>)">Asignar profesor</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'calendar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'calendar']); ?>No hay materias activas sin profesor asignado — ¡todas tienen al menos un profesor para este año lectivo! <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
        <?php if($materiasSinAsignar->hasPages()): ?>
            <div class="sg-card__foot"><?php echo e($materiasSinAsignar->links()); ?></div>
        <?php endif; ?>
        <?php else: ?>
        <div class="overflow-x-auto">
        <table class="sg-tabla">
            <thead>
                <tr>
                    <th>Profesor</th>
                    <th>Materia</th>
                    <th>Días y horarios</th>
                    <th>Aula</th>
                    <th>Año</th>
                    <th></th>
                </tr>
            </thead>
            <tbody class="sg-filas">
                <?php $__empty_1 = true; $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <p class="font-semibold text-slate-800"><?php echo e($asignacion->profesor->apellido); ?>, <?php echo e($asignacion->profesor->nombre); ?></p>
                            <p class="text-xs text-slate-400">
                                <?php echo e($asignacion->profesor->especialidad->nombre_especialidad); ?>

                                <span class="ml-1 sg-badge sg-badge--sin-punto !py-0.5 <?php echo e($asignacion->profesor->condicion === 'Titular' ? 'sg-badge--azul' : 'sg-badge--amarillo'); ?>"><?php echo e($asignacion->profesor->condicion); ?></span>
                            </p>
                        </td>
                        <td>
                            <p class="text-slate-700"><?php echo e($asignacion->materia->nombre); ?></p>
                            <p class="text-xs text-blue-600"><?php echo e($asignacion->materia->carrera->nombre_carrera); ?></p>
                        </td>
                        <td>
                            <div class="flex flex-wrap gap-1.5">
                                <?php $__currentLoopData = $asignacion->horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $payloadHorario = [
                                            'id_profesor' => $asignacion->id_profesor,
                                            'id_materia' => $asignacion->id_materia,
                                            'id_anio_lectivo' => $asignacion->id_anio_lectivo,
                                            'aula' => $asignacion->aula,
                                            'hora_inicio' => substr($horario->hora_desde, 0, 5),
                                            'hora_fin' => substr($horario->hora_fin, 0, 5),
                                            'dias' => [$horario->dia_semana],
                                        ];
                                    ?>
                                    <span class="inline-flex items-center gap-1 rounded-md bg-blue-50 pl-1.5 pr-1 py-0.5 text-[11px] font-bold text-[#0B3D91]">
                                        <?php echo e(\Illuminate\Support\Str::limit($horario->dia_semana, 3, '')); ?> <?php echo e(substr($horario->hora_desde, 0, 5)); ?>–<?php echo e(substr($horario->hora_fin, 0, 5)); ?>

                                        <button type="button" title="Editar este día" class="h-4 w-4 grid place-items-center rounded text-[#0B3D91]/50 hover:text-[#0B3D91] hover:bg-blue-100 transition-colors"
                                                onclick='editarAsignacion(<?php echo json_encode($payloadHorario, 15, 512) ?>)'><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'pencil','class' => '!h-3 !w-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'pencil','class' => '!h-3 !w-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                        <form method="POST" action="<?php echo e(route('admin.profesores.asignaciones.horarios.destroy', [$asignacion, $horario])); ?>" onsubmit="return confirm('¿Quitar el <?php echo e($horario->dia_semana); ?> de esta asignación?');" class="inline-flex">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" title="Quitar este día" class="h-4 w-4 grid place-items-center rounded text-[#0B3D91]/50 hover:text-red-600 hover:bg-red-50 transition-colors"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'x','class' => '!h-3 !w-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'x','class' => '!h-3 !w-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                        </form>
                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                        <td class="text-slate-500"><?php echo e($asignacion->aula ?? '—'); ?></td>
                        <td class="text-slate-500"><?php echo e($asignacion->materia->anioCursada->nombre_anio); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('admin.profesores.asignaciones.destroy', $asignacion)); ?>" onsubmit="return confirm('¿Eliminar esta asignación completa, con todos sus días?');">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="sg-btn sg-btn--peligro sg-btn--icono" title="Eliminar toda la asignación"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'trash','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'trash','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'calendar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'calendar']); ?>No hay asignaciones cargadas. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
        <?php if($asignaciones->hasPages()): ?>
            <div class="sg-card__foot"><?php echo e($asignaciones->links()); ?></div>
        <?php endif; ?>
        <?php endif; ?>
    </div>

    <script>
        function preseleccionarMateria(idMateria) {
            document.getElementById('input-id-materia').value = idMateria;
            actualizarMateriasDisponibles();
            document.getElementById('form-asignacion').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/admin/profesores/index.blade.php ENDPATH**/ ?>