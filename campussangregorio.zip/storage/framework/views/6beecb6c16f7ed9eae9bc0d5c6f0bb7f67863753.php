

<?php $__env->startSection('titulo', 'Cobro de Cuotas'); ?>
<?php $__env->startSection('subtitulo', 'Al registrar el pago, se actualiza el estado del alumno y se asienta como ingreso en el Libro de Caja'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Cobro de Cuotas','subtitulo' => 'Al registrar el pago, se actualiza el estado del alumno y se asienta como ingreso en el Libro de Caja','eyebrow' => 'Finanzas','icono' => 'card']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Cobro de Cuotas','subtitulo' => 'Al registrar el pago, se actualiza el estado del alumno y se asienta como ingreso en el Libro de Caja','eyebrow' => 'Finanzas','icono' => 'card']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="sg-card sg-revelar overflow-hidden mb-8">
        <div class="relative bg-gradient-to-r from-[#082A66] via-[#0B3D91] to-[#1565C0] px-6 py-4 overflow-hidden">
            <span class="absolute -right-8 -top-10 h-28 w-28 rounded-full border-[10px] border-[#FFC107]/25"></span>
            <h2 class="relative text-white font-display font-bold flex items-center gap-3"><span class="grid h-9 w-9 place-items-center rounded-xl bg-white/15 text-[#FFD54F]"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'card','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'card','class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span> Registrar pago de cuota</h2>
        </div>

        <div class="p-6">
            <form method="GET" class="grid sm:grid-cols-[1fr_auto] gap-4 mb-2">
                <div>
                    <label class="sg-label">BUSCAR ALUMNO *</label>
                    <div class="sg-campo-icono">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <input type="text" name="q" value="<?php echo e($busqueda); ?>" placeholder="Nombre, apellido o DNI..." autofocus data-busqueda maxlength="20"
                               oninput="this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÑÜáéíóúñü0-9\s]/g, '')"
                               class="sg-input w-full py-3">
                    </div>
                </div>
                <div class="flex items-end">
                    <button class="sg-btn sg-btn--azul py-3"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Buscar</button>
                </div>
            </form>

            <?php if($resultados->isNotEmpty()): ?>
                <div class="grid gap-2 sm:grid-cols-2 mt-4" data-sg-escalonar>
                    <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('director.cuotas.index', ['alumno' => $alumno->id_usuario])); ?>"
                           class="group flex items-center justify-between gap-3 rounded-2xl border-[1.5px] border-slate-100 hover:border-[#4FC3F7] hover:bg-blue-50/40 hover:-translate-y-0.5 px-4 py-3 transition-all">
                            <div class="flex items-center gap-3">
                                <span class="sg-avatar">
                                    <?php echo e(mb_substr($alumno->nombre, 0, 1)); ?><?php echo e(mb_substr($alumno->apellido, 0, 1)); ?>

                                </span>
                                <div>
                                    <p class="font-semibold text-slate-700 text-sm"><?php echo e($alumno->apellido); ?>, <?php echo e($alumno->nombre); ?></p>
                                    <p class="text-xs text-slate-400">DNI <?php echo e($alumno->dni); ?> · <?php echo e($alumno->persona->inscripcionesCarrera->first()?->carrera?->nombre_carrera); ?></p>
                                </div>
                            </div>
                            <?php if($alumno->cuotas_pendientes_count > 0): ?>
                                <span class="sg-badge sg-badge--amarillo shrink-0"><?php echo e($alumno->cuotas_pendientes_count); ?> cuota(s) pendiente(s)</span>
                            <?php else: ?>
                                <span class="sg-badge sg-badge--verde shrink-0">Al día</span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php elseif($busqueda): ?>
                <p class="sg-aviso sg-aviso--info mt-4">No se encontraron alumnos que coincidan con "<?php echo e($busqueda); ?>".</p>
            <?php endif; ?>

            <?php if($alumnoSeleccionado): ?>
                <?php
                    $cuotasPendientes = $alumnoSeleccionado->persona->cuotas->where('pagado', false);
                    $mesesAdeudados = $estadoMensual->reject(fn ($item) => $item['pagado'])->pluck('mes');
                ?>
                <div class="mt-6 rounded-3xl border border-blue-100 bg-gradient-to-br from-blue-50/80 to-white p-5 sm:p-6 sg-revelar">
                    <div class="flex items-center justify-between mb-5 flex-wrap gap-3">
                        <div class="flex items-center gap-3">
                            <span class="sg-avatar sg-avatar--marca !h-12 !w-12 !rounded-2xl"><?php echo e(mb_substr($alumnoSeleccionado->nombre, 0, 1)); ?><?php echo e(mb_substr($alumnoSeleccionado->apellido, 0, 1)); ?></span>
                            <div>
                            <p class="font-display font-bold text-slate-900"><?php echo e($alumnoSeleccionado->apellido); ?>, <?php echo e($alumnoSeleccionado->nombre); ?></p>
                            <p class="text-xs text-slate-400">DNI <?php echo e($alumnoSeleccionado->dni); ?> · <?php echo e($alumnoSeleccionado->persona->inscripcionesCarrera->first()?->carrera?->nombre_carrera); ?></p>
                            </div>
                        </div>
                        <a href="<?php echo e(route('director.cuotas.index')); ?>" class="sg-btn sg-btn--borde sg-btn--chico"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'refresh']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'refresh']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Cambiar alumno</a>
                    </div>

                    <?php if($estadoMensual->isNotEmpty()): ?>
                        <div class="mb-5">
                            <p class="sg-label mb-2">Estado mes a mes (ciclo <?php echo e(now()->year); ?>)</p>
                            <div class="grid grid-cols-3 sm:grid-cols-6 lg:grid-cols-12 gap-2">
                                <?php $__currentLoopData = $estadoMensual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                            'flex flex-col items-center gap-1 rounded-xl py-2 text-[11px] font-bold ring-1',
                                            'bg-emerald-50 text-emerald-700 ring-emerald-100' => $item['pagado'],
                                            'bg-rose-50 text-rose-600 ring-rose-100' => ! $item['pagado'],
                                        ]) ?>">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => $item['pagado'] ? 'check-circle' : 'x-circle','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['pagado'] ? 'check-circle' : 'x-circle'),'class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        <?php echo e(\Illuminate\Support\Str::limit($item['mes']->nombre_mes, 3, '')); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php
                        $cuotasPorAnio = $alumnoSeleccionado->persona->cuotas->groupBy('id_anio_lectivo')->map(fn ($c) => $c->pluck('id_mes'));
                        $anioVigenteId = $corteActivo?->id_anio_lectivo ?? $anios->first()?->id_anio_lectivo;
                    ?>

                    <details class="mb-5 rounded-2xl border-[1.5px] border-dashed border-slate-200 bg-white open:border-[#BDE5FA] transition-colors">
                        <summary class="cursor-pointer list-none flex items-center gap-3 px-4 py-3 font-semibold text-[#0B3D91] text-sm"><span class="sg-chip sg-chip--chico sg-chip--amarillo"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span> Generar cuota nueva <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'chevron-down','class' => 'h-4 w-4 ml-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'chevron-down','class' => 'h-4 w-4 ml-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></summary>
                        <div class="px-4 pb-4 pt-1 border-t border-slate-100">
                            <form method="POST" action="<?php echo e(route('director.cuotas.generar')); ?>" id="form-generar-cuota">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="alumno_usuario_id" value="<?php echo e($alumnoSeleccionado->id_usuario); ?>">
                                <input type="hidden" name="persona_id" value="<?php echo e($alumnoSeleccionado->persona->id_persona); ?>">

                                <div class="grid sm:grid-cols-2 gap-4 mb-4">
                                    <div>
                                        <label class="sg-label">AÑO LECTIVO *</label>
                                        <select name="id_anio_lectivo" id="select-anio-generar" required class="sg-input w-full">
                                            <?php $__currentLoopData = $anios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($anio->id_anio_lectivo); ?>" <?php if($anio->id_anio_lectivo === $anioVigenteId): echo 'selected'; endif; ?>><?php echo e($anio->anio); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="sg-label">DÍA DE VENCIMIENTO (1-28) *</label>
                                        <input type="number" name="dia_vencimiento" min="1" max="28" value="10" required
                                               class="sg-input w-full">
                                    </div>
                                </div>

                                <div class="grid sm:grid-cols-2 gap-4 mb-4">
                                    <div>
                                        <label class="sg-label">CONCEPTO</label>
                                        <input type="text" name="concepto" data-solo="alfanumerico" data-max-len="20" maxlength="20" placeholder="Cuota mensual"
                                               class="sg-input w-full">
                                    </div>
                                    <div>
                                        <label class="sg-label">MONTO *</label>
                                        <div class="flex items-center gap-1">
                                            <span class="text-slate-400 text-sm">$</span>
                                            <input type="number" step="0.01" min="0.01" name="monto" required
                                                   class="sg-input w-full">
                                        </div>
                                    </div>
                                </div>

                                <p class="sg-label mb-2">Meses a generar</p>
                                <div class="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-4" id="grid-meses-generar">
                                    <?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center gap-2 rounded-xl border-[1.5px] border-slate-200 px-3 py-2 text-sm cursor-pointer transition-colors hover:border-[#4FC3F7] has-[:checked]:border-[#0B3D91] has-[:checked]:bg-blue-50 has-[:checked]:text-[#0B3D91] has-[:disabled]:opacity-40 has-[:disabled]:cursor-not-allowed">
                                            <input type="checkbox" name="meses[]" value="<?php echo e($mes->id_mes); ?>" class="chk-mes-generar h-4 w-4 rounded" data-mes="<?php echo e($mes->id_mes); ?>">
                                            <?php echo e($mes->nombre_mes); ?>

                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <p class="text-xs text-slate-400 mb-4" id="aviso-meses-existentes"></p>

                                <div class="flex justify-end">
                                    <button type="submit" class="sg-btn sg-btn--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'plus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Generar cuota(s)</button>
                                </div>
                            </form>
                        </div>
                    </details>

                    <script>
                        (function () {
                            const cuotasPorAnio = <?php echo json_encode($cuotasPorAnio, 15, 512) ?>;
                            const selectAnio = document.getElementById('select-anio-generar');
                            const aviso = document.getElementById('aviso-meses-existentes');

                            function actualizarMesesDisponibles() {
                                const mesesExistentes = cuotasPorAnio[selectAnio.value] || [];
                                document.querySelectorAll('.chk-mes-generar').forEach(chk => {
                                    const yaExiste = mesesExistentes.includes(parseInt(chk.dataset.mes));
                                    chk.disabled = yaExiste;
                                    chk.checked = false;
                                });
                                aviso.textContent = mesesExistentes.length
                                    ? 'Los meses deshabilitados ya tienen una cuota generada para ese año.'
                                    : '';
                            }

                            selectAnio.addEventListener('change', actualizarMesesDisponibles);
                            actualizarMesesDisponibles();
                        })();
                    </script>

                    <?php if($cuotasPendientes->isEmpty() && $mesesAdeudados->isNotEmpty()): ?>
                        <p class="sg-aviso sg-aviso--alerta">
                            Debe <?php echo e($mesesAdeudados->pluck('nombre_mes')->join(', ')); ?>, pero todavía no se le generó la cuota de <?php echo e($mesesAdeudados->count() > 1 ? 'esos meses' : 'ese mes'); ?>. Generala más abajo para poder cobrarla.
                        </p>
                    <?php elseif($cuotasPendientes->isEmpty()): ?>
                        <p class="sg-aviso sg-aviso--exito"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'check-circle','class' => 'h-5 w-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'check-circle','class' => 'h-5 w-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Este alumno no tiene cuotas pendientes.</p>
                    <?php else: ?>
                        <form id="form-cobrar-cuotas" method="POST" action="<?php echo e(route('director.cuotas.cobrar')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="persona_id" value="<?php echo e($alumnoSeleccionado->persona->id_persona); ?>">
                        </form>

                        <?php if($primerMesSinGenerar): ?>
                            <p class="sg-aviso sg-aviso--alerta mb-3">
                                Debe <?php echo e($primerMesSinGenerar->nombre_mes); ?>, pero todavía no se le generó esa cuota. Las cuotas de meses posteriores quedan bloqueadas hasta que la generes y la cobres.
                            </p>
                        <?php endif; ?>

                        <?php if($montoActual): ?>
                            <div class="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 border border-slate-200 px-4 py-3 mb-4">
                                <span class="text-sm font-semibold text-slate-600">Adeuda <?php echo e($cuotasPendientes->count()); ?> cuota<?php echo e($cuotasPendientes->count() === 1 ? '' : 's'); ?> × $ <?php echo e(number_format($montoActual, 0, ',', '.')); ?> (monto actual)</span>
                                <span class="font-display font-bold text-[#0B3D91]">$ <?php echo e(number_format($cuotasPendientes->count() * $montoActual, 0, ',', '.')); ?></span>
                            </div>
                        <?php endif; ?>

                        <p class="sg-label mb-1">Cuotas pendientes — Seleccioná las que se están pagando y ajustá el monto si corresponde:</p>
                        <p class="text-xs text-slate-400 mb-2">Se cobran en orden: al tildar una cuota se tildan también las anteriores, y no se puede saltear ningún mes.</p>
                        <div class="space-y-2 mb-4">
                            <?php $__currentLoopData = $cuotasPendientes->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $bloqueada = $primerMesSinGenerar
                                        && $cuota->id_anio_lectivo == $primerMesSinGenerar->id_anio_lectivo
                                        && $cuota->id_mes > $primerMesSinGenerar->id_mes;
                                ?>
                                <div class="rounded-2xl bg-white border-[1.5px] border-slate-200 px-4 py-3 transition-colors has-[.cuota-check:checked]:border-[#4FC3F7] has-[.cuota-check:checked]:shadow-md">
                                    <div class="flex items-center justify-between gap-3">
                                        <label class="flex items-center gap-3 cursor-pointer flex-1">
                                            <input type="checkbox" form="form-cobrar-cuotas" name="cuotas[<?php echo e($cuota->id_cuota); ?>][pagar]" value="1" class="h-4 w-4 rounded cuota-check" data-id="<?php echo e($cuota->id_cuota); ?>" data-orden="<?php echo e($loop->index); ?>" <?php if($bloqueada): ?> disabled <?php else: ?> checked <?php endif; ?>>
                                            <span class="font-semibold text-slate-700 text-sm"><?php echo e($cuota->concepto ?: 'Cuota ' . $cuota->mes->nombre_mes); ?></span>
                                            <?php if($bloqueada): ?>
                                                <span class="sg-badge sg-badge--gris">Bloqueada: falta generar <?php echo e($primerMesSinGenerar->nombre_mes); ?></span>
                                            <?php endif; ?>
                                        </label>
                                        <div class="flex items-center gap-1 shrink-0">
                                            <button type="button" onclick="document.getElementById('editar-cuota-<?php echo e($cuota->id_cuota); ?>').classList.toggle('hidden')"
                                                    class="h-8 w-8 grid place-items-center rounded-lg text-slate-400 hover:bg-blue-50 hover:text-[#0B3D91] transition-colors" title="Editar cuota"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'pencil','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'pencil','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                            <form method="POST" action="<?php echo e(route('director.cuotas.eliminar', $cuota)); ?>" onsubmit="return confirm('¿Eliminar esta cuota? Esta acción no se puede deshacer.');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="hidden" name="alumno_usuario_id" value="<?php echo e($alumnoSeleccionado->id_usuario); ?>">
                                                <button type="submit" class="h-8 w-8 grid place-items-center rounded-lg text-slate-400 hover:bg-red-50 hover:text-red-600 transition-colors" title="Eliminar cuota"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'trash','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'trash','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-3">
                                        <div>
                                            <label class="sg-label">Monto</label>
                                            <div class="flex items-center gap-1">
                                                <span class="text-slate-400 text-sm">$</span>
                                                <input type="number" step="0.01" min="0.01" form="form-cobrar-cuotas" name="cuotas[<?php echo e($cuota->id_cuota); ?>][monto]" value="<?php echo e($cuota->monto); ?>"
                                                       class="sg-input sg-input--chico cuota-monto w-full" data-id="<?php echo e($cuota->id_cuota); ?>">
                                            </div>
                                        </div>
                                        <div>
                                            <label class="sg-label !text-amber-600">Recargo por mora</label>
                                            <div class="flex items-center gap-1">
                                                <span class="text-slate-400 text-sm">$</span>
                                                <input type="number" step="0.01" min="0" value="<?php echo e($cuota->recargo); ?>"
                                                       readonly title="Se calcula solo desde Configuración de Cuotas — no se edita acá."
                                                       class="sg-input sg-input--chico cuota-recargo w-full border-amber-200 bg-slate-50 text-slate-500 cursor-not-allowed" data-id="<?php echo e($cuota->id_cuota); ?>">
                                            </div>
                                        </div>
                                        <div class="col-span-2 sm:col-span-1">
                                            <label class="sg-label">Subtotal</label>
                                            <p class="cuota-subtotal font-display font-bold text-[#0B3D91] text-base py-1" data-id="<?php echo e($cuota->id_cuota); ?>">
                                                $ <?php echo e(number_format($cuota->montoTotal(), 0, ',', '.')); ?>

                                            </p>
                                        </div>
                                    </div>

                                    <div id="editar-cuota-<?php echo e($cuota->id_cuota); ?>" class="hidden mt-3 pt-3 border-t border-dashed border-slate-200">
                                        <form method="POST" action="<?php echo e(route('director.cuotas.actualizar', $cuota)); ?>" class="grid grid-cols-2 sm:grid-cols-4 gap-3 items-end">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="alumno_usuario_id" value="<?php echo e($alumnoSeleccionado->id_usuario); ?>">
                                            <div class="col-span-2">
                                                <label class="sg-label">Concepto</label>
                                                <input type="text" name="concepto" data-solo="alfanumerico" data-max-len="20" maxlength="20" value="<?php echo e($cuota->concepto); ?>"
                                                       class="sg-input sg-input--chico w-full">
                                            </div>
                                            <div>
                                                <label class="sg-label">Monto</label>
                                                <input type="number" step="0.01" min="0.01" name="monto" value="<?php echo e($cuota->monto); ?>" required
                                                       class="sg-input sg-input--chico w-full">
                                            </div>
                                            <div>
                                                <label class="sg-label">Vencimiento</label>
                                                <input type="date" name="fecha_vencimiento" value="<?php echo e($cuota->fecha_vencimiento?->toDateString()); ?>"
                                                       class="sg-input sg-input--chico w-full">
                                            </div>
                                            <div class="col-span-2 sm:col-span-4 flex justify-end">
                                                <button type="submit" class="sg-btn sg-btn--azul sg-btn--chico">Guardar cambios de la cuota</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="grid sm:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label class="sg-label">FECHA DE PAGO *</label>
                                <input type="date" form="form-cobrar-cuotas" name="fecha_pago" value="<?php echo e(now()->toDateString()); ?>" required
                                       class="sg-input w-full">
                            </div>
                            <div>
                                <label class="sg-label">MEDIO DE PAGO *</label>
                                <select form="form-cobrar-cuotas" name="medio_pago" required class="sg-input w-full">
                                    <option value="Efectivo">Efectivo</option>
                                    <option value="Transferencia">Transferencia</option>
                                </select>
                            </div>
                        </div>

                        <div class="flex items-center justify-between rounded-2xl bg-gradient-to-r from-[#0B3D91] to-[#1565C0] text-white px-5 py-4 mb-4 shadow-lg shadow-blue-900/20">
                            <span class="font-semibold text-blue-100 text-sm flex items-center gap-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'banknotes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'banknotes']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Total a registrar</span>
                            <span id="total-cobro" class="font-display font-extrabold text-2xl text-[#FFD54F]">$ <?php echo e(number_format($cuotasPendientes->sum(fn ($c) => $c->montoTotal()), 0, ',', '.')); ?></span>
                        </div>

                        <p class="sg-aviso sg-aviso--exito mb-4 text-xs">
                            Al confirmar: el estado de <?php echo e($alumnoSeleccionado->apellido); ?>, <?php echo e($alumnoSeleccionado->nombre); ?> se actualizará y se registrará automáticamente un ingreso en el Libro de Caja.
                        </p>

                        <div class="flex justify-end gap-3">
                            <a href="<?php echo e(route('director.cuotas.index')); ?>" class="sg-btn sg-btn--borde">Cancelar</a>
                            <button type="submit" form="form-cobrar-cuotas" class="sg-btn sg-btn--verde"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'check-circle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'check-circle']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Confirmar cobro y registrar en Caja</button>
                        </div>

                        <script>
                            function recalcularCuota(id) {
                                const monto = parseFloat(document.querySelector(`.cuota-monto[data-id="${id}"]`).value) || 0;
                                const recargo = parseFloat(document.querySelector(`.cuota-recargo[data-id="${id}"]`).value) || 0;
                                document.querySelector(`.cuota-subtotal[data-id="${id}"]`).textContent = '$ ' + (monto + recargo).toLocaleString('es-AR');
                                recalcularTotal();
                            }
                            function recalcularTotal() {
                                let total = 0;
                                document.querySelectorAll('.cuota-check:checked').forEach(cb => {
                                    const id = cb.dataset.id;
                                    const monto = parseFloat(document.querySelector(`.cuota-monto[data-id="${id}"]`).value) || 0;
                                    const recargo = parseFloat(document.querySelector(`.cuota-recargo[data-id="${id}"]`).value) || 0;
                                    total += monto + recargo;
                                });
                                document.getElementById('total-cobro').textContent = '$ ' + total.toLocaleString('es-AR');
                            }
                            // Cobro en orden: tildar una cuota tilda las anteriores; destildarla destilda las posteriores.
                            document.querySelectorAll('.cuota-check').forEach(cb => cb.addEventListener('change', () => {
                                const orden = parseInt(cb.dataset.orden);
                                document.querySelectorAll('.cuota-check:not(:disabled)').forEach(otro => {
                                    const ordenOtro = parseInt(otro.dataset.orden);
                                    if (cb.checked && ordenOtro < orden) otro.checked = true;
                                    if (! cb.checked && ordenOtro > orden) otro.checked = false;
                                });
                                recalcularTotal();
                            }));
                            recalcularTotal();
                            document.querySelectorAll('.cuota-monto, .cuota-recargo').forEach(input => {
                                input.addEventListener('input', () => recalcularCuota(input.dataset.id));
                            });
                        </script>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="sg-card sg-revelar overflow-hidden">
        <div class="sg-card__head">
            <div class="sg-card__titulo">
                <span class="sg-chip sg-chip--chico sg-chip--verde"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'clock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'clock']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <div><h3>Historial de cobros de cuotas</h3><p>Pagos registrados recientemente</p></div>
            </div>
        <form method="GET" class="flex flex-wrap gap-2">
            <input type="text" name="h_alumno" value="<?php echo e($filtroHistorialAlumno); ?>" placeholder="Buscar alumno..." maxlength="25"
                   oninput="this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÑÜáéíóúñü\s]/g, '')"
                   class="sg-input w-auto py-2">
            <button class="sg-btn sg-btn--suave sg-btn--chico"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'filter']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Filtrar</button>
        </form>
        </div>
        <div class="overflow-x-auto">
        <table class="sg-tabla">
            <thead>
                <tr>
                    <th>Alumno</th>
                    <th>Cuota</th>
                    <th>Fecha pago</th>
                    <th>Monto</th>
                    <th>Recargo</th>
                    <th>Medio</th>
                </tr>
            </thead>
            <tbody class="sg-filas">
                <?php $__empty_1 = true; $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><div class="flex items-center gap-3"><span class="sg-avatar"><?php echo e(mb_substr($cuota->personaAlumno->nombre, 0, 1)); ?><?php echo e(mb_substr($cuota->personaAlumno->apellido, 0, 1)); ?></span><span class="font-semibold text-slate-800"><?php echo e($cuota->personaAlumno->apellido); ?>, <?php echo e($cuota->personaAlumno->nombre); ?></span></div></td>
                        <td class="text-slate-500"><?php echo e($cuota->concepto ?: 'Cuota ' . $cuota->mes->nombre_mes); ?></td>
                        <td class="text-slate-500"><?php echo e($cuota->fecha_pago ? \App\Support\FechaEsp::corta($cuota->fecha_pago) : '—'); ?></td>
                        <td class="font-display font-bold !text-emerald-600 whitespace-nowrap">$ <?php echo e(number_format($cuota->monto, 0, ',', '.')); ?></td>
                        <td>
                            <?php if($cuota->recargo > 0): ?>
                                <span class="sg-badge sg-badge--amarillo sg-badge--sin-punto">+$ <?php echo e(number_format($cuota->recargo, 0, ',', '.')); ?></span>
                            <?php else: ?>
                                <span class="text-slate-300">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-slate-500"><?php echo e($cuota->movimientoCaja?->medioPago?->nombre_medio ?? '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'banknotes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'banknotes']); ?>Todavía no hay pagos registrados. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
        <?php if($historial->hasPages()): ?>
            <div class="sg-card__foot"><?php echo e($historial->links()); ?></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.director', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/director/cuotas/index.blade.php ENDPATH**/ ?>