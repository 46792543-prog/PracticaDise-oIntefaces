
<?php if(auth()->guard()->check()): ?>
<script>
    (function () {
        var MARCADOR = 'sg_sesion_activa';
        var MINUTOS_AUSENCIA = 10;
        var PAGINAS_PUBLICAS = /^\/(login|recuperar-contrasena(\/.*)?)?\/?$/;
        var recienLogueado = <?php echo json_encode((bool) session('recien_logueado'), 15, 512) ?>;

        function marcarActividad() {
            try { sessionStorage.setItem(MARCADOR, String(Date.now())); } catch (e) {}
        }

        function cerrarSesion() {
            try { sessionStorage.removeItem(MARCADOR); } catch (e) {}
            document.documentElement.style.visibility = 'hidden';

            var enviar = function () {
                var form = document.createElement('form');
                form.method = 'POST';
                form.action = <?php echo json_encode(route('logout'), 15, 512) ?>;
                form.innerHTML = '<input type="hidden" name="_token" value="' + <?php echo json_encode(csrf_token(), 15, 512) ?> + '">'
                    + '<input type="hidden" name="motivo" value="reingreso">';
                document.body.appendChild(form);
                form.submit();
            };

            document.body ? enviar() : document.addEventListener('DOMContentLoaded', enviar);
        }

        function vieneDeUnaPantallaInterna() {
            try {
                var origen = new URL(document.referrer);
                return origen.origin === location.origin && ! PAGINAS_PUBLICAS.test(origen.pathname);
            } catch (e) {
                return false;
            }
        }

        function estuvoAusente() {
            var ultima = parseInt(sessionStorage.getItem(MARCADOR) || '0', 10);
            return ultima > 0 && Date.now() - ultima > MINUTOS_AUSENCIA * 60 * 1000;
        }

        var marca;
        try { marca = sessionStorage.getItem(MARCADOR); } catch (e) { marca = '1'; }

        if (! recienLogueado) {
            if ((! marca && ! vieneDeUnaPantallaInterna()) || (marca && estuvoAusente())) {
                cerrarSesion();
                return;
            }
        }

        marcarActividad();

        // Mientras la página está abierta se renueva la marca, así una pantalla
        // abierta mucho tiempo no cuenta como "ausencia".
        setInterval(marcarActividad, 60 * 1000);

        // Al volver a la pestaña (o al despertar la compu) se controla de nuevo.
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState !== 'visible') return;
            if (estuvoAusente()) { cerrarSesion(); return; }
            marcarActividad();
        });

        // Si el navegador muestra la página desde su caché al ir "atrás", se la pide de nuevo.
        window.addEventListener('pageshow', function (evento) {
            if (evento.persisted) location.reload();
        });
    })();
</script>
<?php endif; ?>
<?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/partials/session-guard.blade.php ENDPATH**/ ?>