

<?php $__env->startSection('titulo', 'Auditoría'); ?>
<?php $__env->startSection('subtitulo', 'Registro automático de todo lo que se crea, edita o elimina en el sistema'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php
        $estilosAccion = [
            'creado' => ['verde', 'plus'],
            'actualizado' => ['amarillo', 'pencil'],
            'eliminado' => ['rojo', 'trash'],
        ];
        $etiquetasAccion = ['creado' => 'Creó', 'actualizado' => 'Actualizó', 'eliminado' => 'Eliminó'];
    ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.encabezado','data' => ['titulo' => 'Auditoría','subtitulo' => 'Registro automático de todo lo que se crea, edita o elimina en el sistema','eyebrow' => 'Control','icono' => 'shield']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.encabezado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Auditoría','subtitulo' => 'Registro automático de todo lo que se crea, edita o elimina en el sistema','eyebrow' => 'Control','icono' => 'shield']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="sg-card sg-revelar overflow-hidden">
        <div class="sg-card__head">
            <div class="sg-card__titulo">
                <span class="sg-chip sg-chip--chico sg-chip--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'clock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'clock']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                <div><h3>Registro de acciones</h3><p>Las más recientes primero</p></div>
            </div>
        </div>

        <form method="GET" class="flex flex-wrap items-end gap-3 px-6 py-4 border-b border-slate-100 bg-slate-50/60">
            <div>
                <label class="sg-label">Tabla</label>
                <select name="tabla" onchange="this.form.submit()" class="sg-input w-auto min-w-[180px]">
                    <option value="">Todas las tablas</option>
                    <?php $__currentLoopData = $tablas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tabla); ?>" <?php if($filtros['tabla'] === $tabla): echo 'selected'; endif; ?>><?php echo e(\App\Support\AuditoriaFormato::tabla($tabla)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="sg-label">Acción</label>
                <select name="accion" onchange="this.form.submit()" class="sg-input w-auto min-w-[160px]">
                    <option value="">Toda acción</option>
                    <option value="creado" <?php if($filtros['accion'] === 'creado'): echo 'selected'; endif; ?>>Creado</option>
                    <option value="actualizado" <?php if($filtros['accion'] === 'actualizado'): echo 'selected'; endif; ?>>Actualizado</option>
                    <option value="eliminado" <?php if($filtros['accion'] === 'eliminado'): echo 'selected'; endif; ?>>Eliminado</option>
                </select>
            </div>
            <div>
                <label class="sg-label">Desde</label>
                <input type="date" name="desde" value="<?php echo e($filtros['desde']); ?>" placeholder="Desde" class="sg-input w-auto">
            </div>
            <div>
                <label class="sg-label">Hasta</label>
                <input type="date" name="hasta" value="<?php echo e($filtros['hasta']); ?>" placeholder="Hasta" class="sg-input w-auto">
            </div>
            <button class="sg-btn sg-btn--azul"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'filter']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Filtrar</button>
            <?php if($filtros['tabla'] || $filtros['accion'] || $filtros['desde'] || $filtros['hasta']): ?>
                <a href="<?php echo e(route('director.auditoria.index')); ?>" class="sg-btn sg-btn--borde"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'x']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Limpiar</a>
            <?php endif; ?>
        </form>

        <ol class="px-6 py-5 sg-filas">
            <?php $__empty_1 = true; $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php [$tono, $icono] = $estilosAccion[$evento->accion] ?? ['gris', 'info']; ?>
                <li class="relative flex gap-4 pb-6 last:pb-1">
                    <?php if (! ($loop->last)): ?>
                        <span class="absolute left-[19px] top-11 bottom-0 w-px bg-gradient-to-b from-slate-200 to-slate-100"></span>
                    <?php endif; ?>
                    <span class="sg-chip sg-chip--<?php echo e($tono); ?> relative z-10 ring-4 ring-white"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => $icono,'class' => 'h-[18px] w-[18px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icono),'class' => 'h-[18px] w-[18px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
                    <div class="flex-1 min-w-0 rounded-2xl border border-slate-100 bg-white hover:border-blue-200 hover:shadow-sm transition-all px-4 py-3">
                        <div class="flex items-center justify-between gap-3 flex-wrap">
                            <span class="sg-badge sg-badge--<?php echo e($tono); ?>"><?php echo e($etiquetasAccion[$evento->accion] ?? $evento->accion); ?> · <?php echo e(\App\Support\AuditoriaFormato::tabla($evento->tabla)); ?></span>
                            <span class="text-xs text-slate-400 flex items-center gap-1.5">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => 'clock','class' => 'h-3.5 w-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => 'clock','class' => 'h-3.5 w-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php echo e($evento->created_at->format('d/m/Y')); ?> · <?php echo e($evento->created_at->format('H:i')); ?>

                            </span>
                        </div>
                        <p class="text-sm text-slate-700 mt-2"><?php echo e(\App\Support\AuditoriaFormato::descripcion($evento)); ?></p>
                        <?php $detalle = \App\Support\AuditoriaFormato::cambios($evento); ?>
                        <?php if(! empty($detalle)): ?>
                            <details class="mt-1.5">
                                <summary class="text-xs text-[#0B3D91] cursor-pointer select-none font-semibold">Ver detalle</summary>
                                <ul class="mt-1.5 space-y-0.5 text-xs text-slate-500">
                                    <?php $__currentLoopData = $detalle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <span class="font-semibold text-slate-600"><?php echo e($fila['campo']); ?>:</span>
                                            <?php if($fila['valor'] === null): ?>
                                                <?php echo e($fila['antes']); ?> → <span class="text-slate-700 font-medium"><?php echo e($fila['despues']); ?></span>
                                            <?php else: ?>
                                                <?php echo e($fila['valor']); ?>

                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </details>
                        <?php endif; ?>
                        <?php if($evento->usuario): ?>
                            <div class="flex items-center gap-2 mt-2.5">
                                <span class="sg-avatar !h-6 !w-6 !rounded-md !text-[9px]"><?php echo e(mb_substr($evento->usuario->nombre ?? '?', 0, 1)); ?><?php echo e(mb_substr($evento->usuario->apellido ?? '', 0, 1)); ?></span>
                                <span class="text-slate-500 text-xs"><?php echo e($evento->usuario->nombre); ?> <?php echo e($evento->usuario->apellido); ?></span>
                                <span class="sg-badge sg-badge--sin-punto !py-0.5 <?php echo e($evento->usuario->esDirector() ? 'sg-badge--amarillo' : 'sg-badge--gris'); ?>">
                                    <?php echo e($evento->usuario->esDirector() ? 'Dir.' : 'Sec.'); ?>

                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.vacio','data' => ['icono' => 'shield','titulo' => 'Sin registros']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.vacio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icono' => 'shield','titulo' => 'Sin registros']); ?>No hay acciones registradas con estos filtros. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php endif; ?>
        </ol>

        <?php if($eventos->hasPages()): ?>
            <div class="sg-card__foot"><?php echo e($eventos->links()); ?></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.director', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/director/auditoria/index.blade.php ENDPATH**/ ?>