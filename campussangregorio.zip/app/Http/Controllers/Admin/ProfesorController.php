<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AnioLectivo;
use App\Models\AsignacionProfesorMateria;
use App\Models\Carrera;
use App\Models\EspecialidadProfesor;
use App\Models\HorarioAsignacion;
use App\Models\Materia;
use App\Models\Persona;
use App\Models\Profesor;
use App\Support\CorteActivo;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class ProfesorController extends Controller
{
    public function index(Request $request): View
    {
        $anioLectivo = CorteActivo::actual() ?? AnioLectivo::orderByDesc('anio')->first();
        $sinAsignar = $request->boolean('sin_asignar');

        $asignaciones = AsignacionProfesorMateria::with('profesor.persona', 'materia.carrera', 'materia.nombreMateria', 'horarios')
            ->when($anioLectivo, fn ($q) => $q->where('id_anio_lectivo', $anioLectivo->id_anio_lectivo))
            ->when($request->query('profesor'), fn ($q, $p) => $q->where('id_profesor', $p))
            ->when($request->query('dia'), fn ($q, $dia) => $q->whereHas('horarios', fn ($w) => $w->where('dia_semana', ucfirst($dia))))
            ->when($request->query('materia'), fn ($q, $m) => $q->whereHas('materia.nombreMateria', fn ($w) => $w->where('nombre', 'like', "%{$m}%")))
            ->orderByDesc('id_asignacion')
            ->paginate(15, ['*'], 'pagina_asignaciones')
            ->withQueryString();

        $materiasSinAsignar = Materia::with('carrera', 'nombreMateria', 'anioCursada')
            ->where('activa', true)
            ->when($anioLectivo, fn ($q) => $q->whereDoesntHave('asignaciones', fn ($w) => $w->where('id_anio_lectivo', $anioLectivo->id_anio_lectivo)))
            ->when($request->query('materia'), fn ($q, $m) => $q->whereHas('nombreMateria', fn ($w) => $w->where('nombre', 'like', "%{$m}%")))
            ->orderBy('id_carrera')
            ->orderBy('id_anio_cursada')
            ->paginate(15, ['*'], 'pagina_asignaciones')
            ->withQueryString();

        // Días ya tomados de cada materia, para ocultarla del combo cuando otro profesor la dicta ese día.
        $materiasOcupadas = HorarioAsignacion::with('asignacion.profesor.persona')
            ->get()
            ->map(fn ($h) => [
                'id_materia' => $h->asignacion->id_materia,
                'id_anio_lectivo' => $h->asignacion->id_anio_lectivo,
                'id_profesor' => $h->asignacion->id_profesor,
                'profesor' => $h->asignacion->profesor->apellido . ', ' . $h->asignacion->profesor->nombre,
                'dia' => $h->dia_semana,
            ])
            ->values();

        $profesores = Profesor::with('persona', 'especialidad')->get()->sortBy('apellido');

        $profesoresPaginados = Profesor::with('persona', 'especialidad')
            ->join('persona', 'persona.id_persona', '=', 'profesor.id_persona')
            ->orderBy('persona.apellido')
            ->select('profesor.*')
            ->paginate(15, ['*'], 'pagina_profesores')
            ->withQueryString();

        return view('admin.profesores.index', [
            'profesores' => $profesores,
            'profesoresPaginados' => $profesoresPaginados,
            'profesoresActivos' => $profesores->where('activo', true),
            'carreras' => Carrera::orderBy('nombre_carrera')->get(),
            'aniosLectivos' => AnioLectivo::orderByDesc('anio')->get(),
            'anioLectivo' => $anioLectivo,
            'asignaciones' => $asignaciones,
            'materiasSinAsignar' => $materiasSinAsignar,
            'materiasOcupadas' => $materiasOcupadas,
            'sinAsignar' => $sinAsignar,
            'especialidades' => EspecialidadProfesor::orderBy('nombre_especialidad')->get(),
            'filtros' => $request->only('profesor', 'dia', 'materia'),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'dni' => ['required', 'digits:8', 'unique:persona,dni'],
            'nombre' => ['required', 'string', 'max:25', 'regex:/^[\pL\s\'-]+$/u'],
            'apellido' => ['required', 'string', 'max:25', 'regex:/^[\pL\s\'-]+$/u'],
            'email' => ['nullable', 'email', 'max:25', 'unique:profesor,email'],
            'id_especialidad' => ['required', 'exists:especialidad_profesor,id_especialidad'],
            'condicion' => ['required', 'in:Titular,Suplente'],
        ]);

        $persona = Persona::create([
            'dni' => $data['dni'],
            'nombre' => $data['nombre'],
            'apellido' => $data['apellido'],
        ]);

        Profesor::create([
            'id_persona' => $persona->id_persona,
            'email' => $data['email'] ?? null,
            'id_especialidad' => $data['id_especialidad'],
            'condicion' => $data['condicion'],
        ]);

        return back()->with('status', 'Profesor agregado correctamente.');
    }

    public function update(Request $request, Profesor $profesor): RedirectResponse
    {
        $data = $request->validate([
            'dni' => ['required', 'digits:8', 'unique:persona,dni,' . $profesor->id_persona . ',id_persona'],
            'nombre' => ['required', 'string', 'max:50', 'regex:/^[\pL\s\'-]+$/u'],
            'apellido' => ['required', 'string', 'max:50', 'regex:/^[\pL\s\'-]+$/u'],
            'email' => ['nullable', 'email', 'max:100', 'unique:profesor,email,' . $profesor->id_profesor . ',id_profesor'],
            'id_especialidad' => ['required', 'exists:especialidad_profesor,id_especialidad'],
            'condicion' => ['required', 'in:Titular,Suplente'],
        ]);

        $profesor->persona->update([
            'dni' => $data['dni'],
            'nombre' => $data['nombre'],
            'apellido' => $data['apellido'],
        ]);

        $profesor->update([
            'email' => $data['email'] ?? null,
            'id_especialidad' => $data['id_especialidad'],
            'condicion' => $data['condicion'],
        ]);

        return back()->with('status', 'Profesor actualizado correctamente.');
    }

    public function baja(Profesor $profesor): RedirectResponse
    {
        $profesor->update([
            'activo' => false,
            'id_secretario_baja' => Auth::user()->id_persona,
            'fecha_baja' => now(),
        ]);

        return back()->with('status', 'Profesor dado de baja.');
    }

    public function reactivar(Profesor $profesor): RedirectResponse
    {
        $profesor->update([
            'activo' => true,
            'id_secretario_reactiva' => Auth::user()->id_persona,
            'fecha_reactivacion' => now(),
        ]);

        return back()->with('status', 'Profesor reactivado.');
    }

    public function storeEspecialidad(Request $request): RedirectResponse|JsonResponse
    {
        $data = $request->validate([
            'nombre_especialidad' => ['required', 'string', 'max:45', 'unique:especialidad_profesor,nombre_especialidad'],
        ]);

        $especialidad = EspecialidadProfesor::create($data);

        if ($request->expectsJson()) {
            return response()->json(['status' => 'Especialidad agregada correctamente.', 'especialidad' => $especialidad]);
        }

        return back()->with('status', 'Especialidad agregada correctamente.');
    }

    public function updateEspecialidad(Request $request, EspecialidadProfesor $especialidad): RedirectResponse|JsonResponse
    {
        $data = $request->validate([
            'nombre_especialidad' => ['required', 'string', 'max:45', 'unique:especialidad_profesor,nombre_especialidad,' . $especialidad->id_especialidad . ',id_especialidad'],
        ]);

        $especialidad->update($data);

        if ($request->expectsJson()) {
            return response()->json(['status' => 'Especialidad actualizada correctamente.', 'especialidad' => $especialidad]);
        }

        return back()->with('status', 'Especialidad actualizada correctamente.');
    }

    public function destroyEspecialidad(Request $request, EspecialidadProfesor $especialidad): RedirectResponse|JsonResponse
    {
        if (Profesor::where('id_especialidad', $especialidad->id_especialidad)->exists()) {
            $mensaje = 'No se puede eliminar: hay profesores cargados con esta especialidad. Cambiales la especialidad primero.';

            if ($request->expectsJson()) {
                return response()->json(['message' => $mensaje], 422);
            }

            return back()->withErrors(['nombre_especialidad' => $mensaje]);
        }

        $especialidad->delete();

        if ($request->expectsJson()) {
            return response()->json(['status' => 'Especialidad eliminada.']);
        }

        return back()->with('status', 'Especialidad eliminada.');
    }

    public function storeAsignacion(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'id_profesor' => ['required', 'exists:profesor,id_profesor'],
            'id_materia' => ['required', 'exists:materia,id_materia'],
            'id_anio_lectivo' => ['required', 'exists:anio_lectivo,id_anio_lectivo'],
            'aula' => ['nullable', 'string', 'max:20'],
            'hora_inicio' => ['required'],
            'hora_fin' => ['required', 'after:hora_inicio'],
            'dias' => ['required', 'array', 'min:1'],
            'dias.*' => ['in:Lunes,Martes,Miercoles,Jueves,Viernes'],
        ]);

        $idAsignacionActual = AsignacionProfesorMateria::where([
            'id_profesor' => $data['id_profesor'],
            'id_materia' => $data['id_materia'],
            'id_anio_lectivo' => $data['id_anio_lectivo'],
        ])->value('id_asignacion');

        // Una materia ya asignada a otro profesor en el mismo año lectivo no se puede volver a asignar.
        $materiaOcupada = AsignacionProfesorMateria::where('id_materia', $data['id_materia'])
            ->where('id_anio_lectivo', $data['id_anio_lectivo'])
            ->where('id_profesor', '!=', $data['id_profesor'])
            ->with('profesor.persona', 'materia')
            ->first();

        if ($materiaOcupada) {
            $otroProfesor = $materiaOcupada->profesor;

            return back()->withErrors([
                'id_materia' => "\"{$materiaOcupada->materia->nombre}\" ya está asignada a {$otroProfesor->apellido}, {$otroProfesor->nombre} en este año lectivo. Elegí otra materia.",
            ])->withInput();
        }

        // Un profesor no puede dar dos materias el mismo día en horarios que se pisan.
        $conflicto = HorarioAsignacion::whereIn('dia_semana', $data['dias'])
            ->where('hora_desde', '<', $data['hora_fin'])
            ->where('hora_fin', '>', $data['hora_inicio'])
            ->whereHas('asignacion', function ($q) use ($data, $idAsignacionActual) {
                $q->where('id_profesor', $data['id_profesor'])
                    ->where('id_anio_lectivo', $data['id_anio_lectivo']);

                if ($idAsignacionActual) {
                    $q->where('id_asignacion', '!=', $idAsignacionActual);
                }
            })
            ->with('asignacion.materia')
            ->first();

        if ($conflicto) {
            $materiaConflicto = $conflicto->asignacion->materia->nombre;

            return back()->withErrors([
                'hora_inicio' => "El profesor ya tiene asignada \"{$materiaConflicto}\" el {$conflicto->dia_semana} de {$conflicto->hora_desde} a {$conflicto->hora_fin}, y se superpone con este horario.",
            ])->withInput();
        }

        $asignacion = AsignacionProfesorMateria::updateOrCreate(
            [
                'id_profesor' => $data['id_profesor'],
                'id_materia' => $data['id_materia'],
                'id_anio_lectivo' => $data['id_anio_lectivo'],
            ],
            [
                'fecha_asignacion' => now(),
                'aula' => $data['aula'] ?? null,
            ]
        );

        // Solo se reemplazan los horarios de los días que vienen en este envío
        // — así se puede cargar un día con un horario y, en otro envío
        // aparte, agregarle otro día con un horario distinto sin perder el
        // primero (es el mismo profesor+materia+año, una sola asignación con
        // varios bloques de día/hora).
        $asignacion->horarios()->whereIn('dia_semana', $data['dias'])->delete();

        foreach ($data['dias'] as $dia) {
            HorarioAsignacion::create([
                'id_asignacion' => $asignacion->id_asignacion,
                'dia_semana' => $dia,
                'hora_desde' => $data['hora_inicio'],
                'hora_fin' => $data['hora_fin'],
            ]);
        }

        return back()->with('status', 'Asignación guardada correctamente.');
    }

    public function destroyAsignacion(AsignacionProfesorMateria $asignacion): RedirectResponse
    {
        $asignacion->horarios()->delete();
        $asignacion->delete();

        return back()->with('status', 'Asignación eliminada.');
    }

    /**
     * Quita un solo bloque de día/horario de una asignación (ej. solo el
     * Viernes, dejando el Miércoles intacto). Si era el último que le
     * quedaba, no tiene sentido una asignación sin ningún horario, así que
     * se borra también.
     */
    public function destroyHorario(AsignacionProfesorMateria $asignacion, HorarioAsignacion $horario): RedirectResponse
    {
        abort_unless($horario->id_asignacion === $asignacion->id_asignacion, 404);

        $horario->delete();

        if ($asignacion->horarios()->doesntExist()) {
            $asignacion->delete();

            return back()->with('status', 'Se quitó el horario y, al no quedarle ninguno, se eliminó la asignación.');
        }

        return back()->with('status', 'Se quitó ese día de la asignación.');
    }
}
