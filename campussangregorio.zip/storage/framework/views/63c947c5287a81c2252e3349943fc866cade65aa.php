<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo e($config?->nombre_institucion ?? 'Instituto Superior San Gregorio'); ?> — Tecnicatura Superior en Enfermería. Formación con compromiso, prácticas desde 1er año y título oficial.">
    <title><?php echo e($config?->nombre_institucion ?? 'Instituto Superior San Gregorio'); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Sora:wght@600;700;800&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
    <link rel="stylesheet" href="<?php echo e(asset('css/landing.css')); ?>?v=<?php echo e(filemtime(public_path('css/landing.css'))); ?>">
</head>
<body class="landing-body">

    <?php echo $__env->make('landing.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <?php echo $__env->make('landing.partials.hero', ['imagenesHero' => $imagenesHero], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('landing.partials.carrusel', ['novedades' => $novedades], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('landing.partials.nosotros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('landing.partials.servicios', ['servicios' => $servicios], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('landing.partials.contadores', ['contadores' => $contadores], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('landing.partials.carreras', ['carreras' => $carreras, 'planesPorCarrera' => $planesPorCarrera], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('landing.partials.ubicacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>

    <?php echo $__env->make('landing.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/landing.js')); ?>?v=<?php echo e(filemtime(public_path('js/landing.js'))); ?>" defer></script>
</body>
</html>
<?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/landing/index.blade.php ENDPATH**/ ?>