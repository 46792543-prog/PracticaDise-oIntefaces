
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['titulo', 'subtitulo' => null, 'eyebrow' => null, 'icono' => 'sparkles']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['titulo', 'subtitulo' => null, 'eyebrow' => null, 'icono' => 'sparkles']); ?>
<?php foreach (array_filter((['titulo', 'subtitulo' => null, 'eyebrow' => null, 'icono' => 'sparkles']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div <?php echo e($attributes->merge(['class' => 'sg-encabezado sg-revelar'])); ?>>
    <div class="sg-encabezado__info">
        <span class="sg-encabezado__icono"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sg.icono','data' => ['nombre' => $icono]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sg.icono'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icono)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></span>
        <div class="min-w-0">
            <?php if($eyebrow): ?>
                <span class="sg-eyebrow"><?php echo e($eyebrow); ?></span>
            <?php endif; ?>
            <h1><?php echo e($titulo); ?></h1>
            <?php if($subtitulo): ?>
                <p class="sg-encabezado__sub"><?php echo e($subtitulo); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <?php if(trim($slot) !== ''): ?>
        <div class="sg-encabezado__acciones"><?php echo e($slot); ?></div>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\PracticaSanGregorio\resources\views/components/sg/encabezado.blade.php ENDPATH**/ ?>